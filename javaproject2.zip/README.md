# School Dropout & Literacy Rate Tracker

A comprehensive web-based platform for monitoring school dropout rates and literacy statistics across different regions. This application provides interactive tools for NGOs and government departments to track educational progress, analyze trends, and manage awareness campaigns effectively.

## 🎯 Project Overview

The School Dropout & Literacy Rate Tracker is designed to help educational stakeholders:
- Monitor dropout and literacy rates across different regions
- Visualize educational statistics through interactive maps and charts
- Manage awareness campaigns with role-based access control
- Analyze trends and generate insights for better decision-making

## ✨ Features Currently Implemented

### 🔐 Authentication System
- **Two User Types**: Government and NGO users with different access levels
- **Session Management**: Secure login/logout with session persistence
- **Role-Based Access Control**: Different permissions for government vs NGO users
- **Demo Credentials**:
  - Government: `gov@example.com` / `gov123`
  - NGO: `ngo@example.com` / `ngo123`

### 🗺️ Interactive Regional Map
- **Leaflet-Based Map**: Interactive map of India with regional markers
- **Data Layers**: Toggle between dropout rate, literacy rate, and enrollment data
- **Education Levels**: Filter by primary, secondary, and higher education
- **Region Details**: Click on regions for detailed statistics and demographics
- **Search Functionality**: Search and filter regions by name
- **Visual Indicators**: Color-coded markers based on performance metrics

### 📊 Analysis Dashboard
- **Overview Statistics**: Key metrics display with trend indicators
- **Interactive Charts**: 
  - Dropout rate trends over time (Line chart)
  - Regional comparison (Bar chart)
  - Gender-wise distribution (Doughnut chart)
  - Age group analysis (Radar chart)
- **Data Export**: Export regional statistics to CSV format
- **Filter Controls**: Time range and category filters for detailed analysis
- **Responsive Tables**: Searchable and sortable data tables

### 📢 Campaign Management
- **NGO Access**: Full CRUD operations for campaign management
- **Government Access**: View-only access to existing campaigns
- **Campaign Types**: Awareness, Enrollment, Literacy, and Retention campaigns
- **Progress Tracking**: Visual progress bars and success rate metrics
- **Regional Targeting**: Assign campaigns to specific regions
- **Detailed Views**: Comprehensive campaign information and metrics

## 🏗️ Technical Architecture

### Frontend Technologies
- **HTML5**: Semantic markup with accessibility features
- **CSS3**: Modern styling with CSS Grid and Flexbox
- **Vanilla JavaScript**: No frameworks, pure JS for maximum performance
- **Chart.js**: Interactive data visualization
- **Leaflet**: Interactive mapping functionality
- **Font Awesome**: Icon library
- **Google Fonts**: Typography (Inter font family)

### Data Management
- **Client-Side Storage**: Local storage for user sessions and preferences
- **Dummy Data**: Comprehensive dataset covering 10 major Indian states
- **Dynamic Updates**: Real-time data filtering and visualization updates

## 📁 Project Structure

```
school-dropout-tracker/
├── index.html              # Login page
├── map.html               # Interactive regional map
├── analysis.html          # Data analysis dashboard
├── campaigns.html         # Campaign management
├── css/
│   └── style.css         # Main stylesheet (responsive design)
├── js/
│   ├── auth.js           # Authentication and session management
│   ├── data.js           # Comprehensive dummy data store
│   ├── login.js          # Login page functionality
│   ├── navigation.js     # Navigation and UI components
│   ├── map.js            # Interactive map functionality
│   ├── analysis.js       # Charts and analytics
│   └── campaigns.js      # Campaign management system
└── README.md             # Project documentation
```

## 🎨 User Interface Features

### Responsive Design
- **Mobile-First**: Optimized for mobile devices and tablets
- **Breakpoints**: Responsive layouts for all screen sizes
- **Touch-Friendly**: Large buttons and touch targets
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation

### Modern UI Components
- **Clean Design**: Professional interface suitable for government/NGO use
- **Consistent Theming**: CSS variables for consistent color scheme
- **Interactive Elements**: Hover effects, transitions, and animations
- **Loading States**: User feedback during data operations
- **Toast Notifications**: Success/error message system

## 📊 Data Coverage

### Regional Data (10 States)
1. **Uttar Pradesh** - Highest population, challenging metrics
2. **Maharashtra** - Strong performance, urban focus
3. **Bihar** - Rural challenges, improvement trends
4. **West Bengal** - Balanced urban-rural distribution
5. **Madhya Pradesh** - Central India representation
6. **Tamil Nadu** - Southern excellence model
7. **Rajasthan** - Gender gap focus
8. **Karnataka** - IT hub with educational progress
9. **Gujarat** - Industrial state performance
10. **Kerala** - Best-in-class literacy rates

### Statistical Categories
- **Dropout Rates**: Primary, Secondary, Higher education levels
- **Literacy Rates**: Overall, Male, Female breakdowns
- **Enrollment Rates**: By education level
- **Demographics**: Rural/Urban split, poverty indicators
- **Trends**: 4-year historical data (2021-2024)

### Campaign Data
- **8 Sample Campaigns**: Different types and statuses
- **Regional Distribution**: Campaigns across various states
- **Progress Tracking**: Reach metrics and success rates
- **Detailed Activities**: Specific campaign actions and outcomes

## 🔑 Functional Entry Points

### Public Access
- **`index.html`**: Login page with demo credentials
- **Authentication**: Required for all dashboard pages

### Dashboard Pages (Authenticated)
- **`map.html`**: 
  - Parameters: `?layer=dropout|literacy|enrollment&level=primary|secondary|higher&year=2021-2024`
  - Interactive map with regional data visualization
  
- **`analysis.html`**:
  - Parameters: `?timeRange=1year|3years|5years&filter=monthly|quarterly|yearly`
  - Analytics dashboard with charts and statistics
  
- **`campaigns.html`**:
  - Parameters: `?filter=all|active|planned|completed`
  - Campaign management (role-dependent access)

## 🚀 Getting Started

### Local Development
1. **Clone or Download**: Get the project files
2. **Open in Browser**: Simply open `index.html` in a modern web browser
3. **Login**: Use demo credentials (auto-filled on page load)
4. **Explore**: Navigate through different sections

### Demo Credentials
```
Government User:
Email: gov@example.com
Password: gov123

NGO User:
Email: ngo@example.com  
Password: ngo123
```

### Browser Compatibility
- **Chrome**: 90+ (Recommended)
- **Firefox**: 88+
- **Safari**: 14+
- **Edge**: 90+

## 🎛️ User Permissions

### Government Users Can:
- ✅ View interactive regional map
- ✅ Access analysis dashboard and charts
- ✅ View existing campaigns (read-only)
- ✅ Export data in CSV format
- ❌ Create/edit/delete campaigns

### NGO Users Can:
- ✅ Full access to all government features
- ✅ Create new awareness campaigns
- ✅ Edit existing campaigns
- ✅ Delete campaigns
- ✅ Track campaign progress and metrics

## 🛠️ Technical Features

### Performance Optimizations
- **Lazy Loading**: Charts initialized only when needed
- **Efficient DOM Manipulation**: Minimal reflows and repaints
- **CSS Grid/Flexbox**: Modern layout without heavy frameworks
- **Optimized Images**: Vector icons and compressed assets

### Security Features
- **Session Management**: Secure client-side session handling
- **Input Validation**: Form validation and sanitization
- **Role-Based Access**: Permission checks throughout the application
- **Activity Logging**: User action tracking for audit trails

### Data Visualization
- **Chart.js Integration**: Professional charts with animations
- **Interactive Maps**: Leaflet with custom markers and popups
- **Real-time Updates**: Dynamic chart updates based on filters
- **Export Functionality**: CSV data export capabilities

## 🎯 Features Not Yet Implemented

### Advanced Features (Future Enhancements)
- **Real-time Data Sync**: Server-side data synchronization
- **Advanced Analytics**: Predictive modeling and ML insights
- **Bulk Operations**: Batch campaign management
- **Email Notifications**: Campaign status and alert system
- **Advanced Reporting**: PDF report generation
- **Multi-language Support**: Regional language options
- **Offline Mode**: Progressive Web App capabilities
- **API Integration**: REST API for external data sources

### Administrative Features
- **User Management**: Admin panel for user creation/management
- **Audit Logs**: Comprehensive activity logging and reporting
- **Data Import/Export**: Bulk data operations
- **System Configuration**: Customizable settings and preferences

## 📈 Recommended Next Steps

1. **Backend Integration**: 
   - Implement REST API for real data management
   - Add database connectivity (PostgreSQL/MongoDB)
   - Set up user authentication server

2. **Enhanced Analytics**:
   - Add more chart types and visualizations
   - Implement predictive analytics
   - Create automated reports and insights

3. **Campaign Enhancement**:
   - Add file upload capabilities
   - Implement campaign templates
   - Create campaign scheduling features

4. **Mobile App Development**:
   - React Native or Flutter mobile application
   - Offline data synchronization
   - Push notifications for campaign updates

5. **Integration Capabilities**:
   - Government database integration
   - Third-party analytics platforms
   - Social media campaign tracking

## 🌐 Deployment

### Current Status
- **Static Website**: Ready for deployment to any web server
- **No Dependencies**: Self-contained with CDN resources
- **Responsive**: Works on all devices and screen sizes

### Deployment Options
1. **GitHub Pages**: Free static hosting
2. **Netlify**: Easy deployment with form handling
3. **Vercel**: Fast global deployment
4. **Traditional Web Hosting**: Any Apache/Nginx server

### Production Checklist
- [ ] Minify CSS and JavaScript files
- [ ] Optimize images and assets
- [ ] Set up proper caching headers
- [ ] Configure HTTPS
- [ ] Add error monitoring
- [ ] Set up analytics tracking

## 🤝 Contributing

This project welcomes contributions for:
- Bug fixes and improvements
- New feature implementations
- UI/UX enhancements
- Documentation updates
- Testing and quality assurance

## 📄 License

This project is designed for educational and demonstration purposes. It can be freely used and modified for non-commercial applications related to education monitoring and campaign management.

---

**Built with ❤️ for better education monitoring and awareness campaign management.**

For questions or support, refer to the comprehensive inline documentation and comments throughout the codebase.