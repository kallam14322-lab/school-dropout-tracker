// Login page functionality

document.addEventListener('DOMContentLoaded', function() {
    // Wait for AuthManager to be fully loaded
    function checkAuthManager() {
        if (typeof window.AuthManager !== 'undefined' && window.AuthManager && typeof window.AuthManager.isAuthenticated === 'function') {
            // Check if already authenticated
            if (window.AuthManager.isAuthenticated()) {
                window.AuthManager.redirectToDashboard();
                return;
            }
            initializeLoginForm();
        } else {
            // Retry after a short delay
            setTimeout(checkAuthManager, 50);
        }
    }
    
    checkAuthManager();
});

function initializeLoginForm() {
    const loginForm = document.getElementById('loginForm');
    const userTypeButtons = document.querySelectorAll('.user-type-btn');
    const passwordToggle = document.getElementById('passwordToggle');
    const passwordInput = document.getElementById('password');
    const emailInput = document.getElementById('email');
    
    let selectedUserType = 'government'; // Default selection
    
    // Handle user type selection
    userTypeButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            userTypeButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Update selected user type
            selectedUserType = this.getAttribute('data-type');
            
            // Auto-fill demo credentials
            if (selectedUserType === 'government') {
                emailInput.value = 'gov@example.com';
                passwordInput.value = 'gov123';
            } else {
                emailInput.value = 'ngo@example.com';
                passwordInput.value = 'ngo123';
            }
        });
    });
    
    // Handle password visibility toggle
    if (passwordToggle && passwordInput) {
        passwordToggle.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            const icon = this.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    }
    
    // Handle form submission
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Handle Enter key press
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleLogin(e);
        }
    });
    
    // Initialize with government credentials by default
    emailInput.value = 'gov@example.com';
    passwordInput.value = 'gov123';
}

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const selectedUserType = document.querySelector('.user-type-btn.active')?.getAttribute('data-type');
    const submitButton = document.querySelector('.login-btn');
    
    // Clear any existing error messages
    clearErrorMessages();
    
    // Validate form
    const validation = window.AuthManager.validateLoginForm(email, password, selectedUserType);
    if (!validation.isValid) {
        displayErrors(validation.errors);
        return;
    }
    
    // Disable submit button and show loading state
    setLoadingState(submitButton, true);
    
    // Simulate network delay for better UX
    setTimeout(() => {
        // Log login attempt
        window.AuthManager.logActivity('login_attempt', {
            email: email,
            userType: selectedUserType,
            timestamp: new Date().toISOString()
        });
        
        // Check for suspicious activity
        const suspiciousActivity = window.AuthManager.detectSuspiciousActivity();
        if (suspiciousActivity.suspicious) {
            displayError('Too many login attempts. Please try again later.');
            setLoadingState(submitButton, false);
            return;
        }
        
        // Attempt authentication
        const authResult = window.AuthManager.authenticate(email, password, selectedUserType);
        
        if (authResult.success) {
            // Log successful login
            window.AuthManager.logActivity('login_success', {
                email: email,
                userType: selectedUserType
            });
            
            // Show success message
            displaySuccess('Login successful! Redirecting to dashboard...');
            
            // Redirect after short delay
            setTimeout(() => {
                window.AuthManager.redirectToDashboard();
            }, 1500);
        } else {
            // Log failed login
            window.AuthManager.logActivity('login_failed', {
                email: email,
                userType: selectedUserType,
                reason: authResult.message
            });
            
            displayError(authResult.message);
        }
        
        setLoadingState(submitButton, false);
    }, 1000);
}

function setLoadingState(button, isLoading) {
    if (isLoading) {
        button.disabled = true;
        button.innerHTML = `
            <i class="fas fa-spinner fa-spin"></i>
            Signing In...
        `;
        button.classList.add('loading');
    } else {
        button.disabled = false;
        button.innerHTML = `
            <i class="fas fa-sign-in-alt"></i>
            Sign In
        `;
        button.classList.remove('loading');
    }
}

function displayErrors(errors) {
    let errorContainer = document.getElementById('errorContainer');
    
    // Create error container if it doesn't exist
    if (!errorContainer) {
        errorContainer = document.createElement('div');
        errorContainer.id = 'errorContainer';
        errorContainer.className = 'error-container';
        
        const loginForm = document.getElementById('loginForm');
        loginForm.parentNode.insertBefore(errorContainer, loginForm);
    }
    
    const errorHTML = errors.map(error => `
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <span>${error}</span>
        </div>
    `).join('');
    
    errorContainer.innerHTML = errorHTML;
    errorContainer.style.display = 'block';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        errorContainer.style.display = 'none';
    }, 5000);
}

function displayError(message) {
    displayErrors([message]);
}

function displaySuccess(message) {
    let successContainer = document.getElementById('successContainer');
    
    // Create success container if it doesn't exist
    if (!successContainer) {
        successContainer = document.createElement('div');
        successContainer.id = 'successContainer';
        successContainer.className = 'success-container';
        
        const loginForm = document.getElementById('loginForm');
        loginForm.parentNode.insertBefore(successContainer, loginForm);
    }
    
    successContainer.innerHTML = `
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        </div>
    `;
    successContainer.style.display = 'block';
    
    // Auto-hide after 3 seconds
    setTimeout(() => {
        successContainer.style.display = 'none';
    }, 3000);
}

function clearErrorMessages() {
    const errorContainer = document.getElementById('errorContainer');
    const successContainer = document.getElementById('successContainer');
    
    if (errorContainer) {
        errorContainer.style.display = 'none';
    }
    
    if (successContainer) {
        successContainer.style.display = 'none';
    }
}

// Handle "Forgot Password" functionality (demo only)
document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('forgot-password')) {
        e.preventDefault();
        
        const selectedUserType = document.querySelector('.user-type-btn.active')?.getAttribute('data-type');
        let message = 'Password reset functionality is not implemented in this demo.';
        
        if (selectedUserType === 'government') {
            message += ' Demo credentials: gov@example.com / gov123';
        } else {
            message += ' Demo credentials: ngo@example.com / ngo123';
        }
        
        alert(message);
    }
});

// Add form input animations and validation
function addInputAnimations() {
    const inputs = document.querySelectorAll('.input-group input');
    
    inputs.forEach(input => {
        // Add focus/blur animations
        input.addEventListener('focus', function() {
            this.parentNode.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentNode.classList.remove('focused');
            }
        });
        
        // Real-time validation
        input.addEventListener('input', function() {
            this.classList.remove('error');
            const errorContainer = document.getElementById('errorContainer');
            if (errorContainer) {
                errorContainer.style.display = 'none';
            }
        });
    });
}

// Initialize animations when DOM is loaded
document.addEventListener('DOMContentLoaded', addInputAnimations);

// Add CSS for alerts if not already present
const alertStyles = `
    .error-container, .success-container {
        margin: 20px 0;
    }
    
    .alert {
        padding: 12px 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 8px;
        font-size: 14px;
        animation: slideIn 0.3s ease-out;
    }
    
    .alert-error {
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.3);
        color: #dc2626;
    }
    
    .alert-success {
        background: rgba(16, 185, 129, 0.1);
        border: 1px solid rgba(16, 185, 129, 0.3);
        color: #059669;
    }
    
    .alert i {
        flex-shrink: 0;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .input-group.focused {
        transform: scale(1.02);
        transition: transform 0.2s ease;
    }
    
    .login-btn.loading {
        opacity: 0.7;
        cursor: not-allowed;
    }
    
    .fa-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;

// Add styles to head
const styleSheet = document.createElement('style');
styleSheet.textContent = alertStyles;
document.head.appendChild(styleSheet);