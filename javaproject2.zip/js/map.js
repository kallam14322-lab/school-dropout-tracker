// Interactive map functionality for regional data visualization

let map;
let mapData;
let regionMarkers = {};
let currentLayer = 'dropout';
let currentEducationLevel = 'primary';
let currentYear = '2024';

// Initialize map when page loads
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('map')) {
        initializeMap();
        initializeMapControls();
        initializeRegionSearch();
    }
});

function initializeMap() {
    // Initialize Leaflet map centered on India
    map = L.map('map').setView([20.5937, 78.9629], 5);
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18,
    }).addTo(map);
    
    // Load and display regional data
    loadRegionalData();
    
    // Log map initialization
    AuthManager.logActivity('map_initialized', {
        initialLayer: currentLayer,
        educationLevel: currentEducationLevel,
        year: currentYear
    });
}

function loadRegionalData() {
    mapData = DataStore.getRegionalData();
    displayRegionalMarkers();
}

function displayRegionalMarkers() {
    // Clear existing markers
    clearMarkers();
    
    Object.entries(mapData).forEach(([regionCode, regionData]) => {
        const marker = createRegionMarker(regionCode, regionData);
        regionMarkers[regionCode] = marker;
        marker.addTo(map);
    });
}

function createRegionMarker(regionCode, regionData) {
    const coordinates = regionData.coordinates;
    const value = getDisplayValue(regionData);
    const color = getMarkerColor(value);
    const size = getMarkerSize(regionData.population);
    
    // Create custom marker
    const marker = L.circleMarker(coordinates, {
        radius: size,
        fillColor: color,
        color: '#ffffff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8,
        regionCode: regionCode
    });
    
    // Add popup
    const popupContent = createPopupContent(regionData);
    marker.bindPopup(popupContent);
    
    // Add hover effects
    marker.on('mouseover', function() {
        this.setStyle({
            weight: 3,
            fillOpacity: 1
        });
        
        if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
            this.bringToFront();
        }
        
        // Show region info panel
        showRegionInfoPanel(regionData);
    });
    
    marker.on('mouseout', function() {
        this.setStyle({
            weight: 2,
            fillOpacity: 0.8
        });
    });
    
    marker.on('click', function() {
        showDetailedRegionInfo(regionCode, regionData);
        
        // Log region selection
        AuthManager.logActivity('region_selected', {
            region: regionData.name,
            layer: currentLayer,
            educationLevel: currentEducationLevel
        });
    });
    
    return marker;
}

function getDisplayValue(regionData) {
    let value;
    
    switch (currentLayer) {
        case 'dropout':
            value = regionData.dropoutRate[currentEducationLevel];
            break;
        case 'literacy':
            value = regionData.literacyRate.overall;
            break;
        case 'enrollment':
            value = regionData.enrollmentRate[currentEducationLevel];
            break;
        default:
            value = regionData.dropoutRate[currentEducationLevel];
    }
    
    return value;
}

function getMarkerColor(value) {
    if (currentLayer === 'dropout') {
        // Higher dropout rate = worse (red)
        if (value > 20) return '#d73027';
        if (value > 15) return '#fc8d59';
        if (value > 10) return '#fee08b';
        return '#91cf60';
    } else {
        // Higher literacy/enrollment = better (green)
        if (value > 80) return '#91cf60';
        if (value > 70) return '#fee08b';
        if (value > 60) return '#fc8d59';
        return '#d73027';
    }
}

function getMarkerSize(population) {
    // Scale marker size based on population
    const baseSize = 8;
    const maxSize = 25;
    const minSize = 5;
    
    // Normalize population (largest state is ~200M)
    const normalizedPop = Math.log(population) / Math.log(200000000);
    return Math.max(minSize, Math.min(maxSize, baseSize + (normalizedPop * 15)));
}

function createPopupContent(regionData) {
    const dropoutRate = regionData.dropoutRate[currentEducationLevel];
    const literacyRate = regionData.literacyRate.overall;
    const enrollmentRate = regionData.enrollmentRate[currentEducationLevel];
    
    return `
        <div class="map-popup">
            <h4>${regionData.name}</h4>
            <div class="popup-stats">
                <div class="stat-row">
                    <span class="stat-label">Population:</span>
                    <span class="stat-value">${formatNumber(regionData.population)}</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Dropout Rate:</span>
                    <span class="stat-value ${dropoutRate > 15 ? 'high-risk' : 'low-risk'}">${dropoutRate}%</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Literacy Rate:</span>
                    <span class="stat-value ${literacyRate > 75 ? 'good' : 'needs-improvement'}">${literacyRate}%</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Enrollment Rate:</span>
                    <span class="stat-value ${enrollmentRate > 85 ? 'good' : 'needs-improvement'}">${enrollmentRate}%</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Active Campaigns:</span>
                    <span class="stat-value">${regionData.activeCampaigns}</span>
                </div>
            </div>
            <div class="popup-actions">
                <button class="btn-primary" onclick="showDetailedRegionInfo('${getRegionCodeByName(regionData.name)}', arguments[0])">View Details</button>
            </div>
        </div>
    `;
}

function formatNumber(num) {
    if (num >= 10000000) {
        return (num / 10000000).toFixed(1) + 'Cr';
    } else if (num >= 100000) {
        return (num / 100000).toFixed(1) + 'L';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function getRegionCodeByName(name) {
    for (const [code, data] of Object.entries(mapData)) {
        if (data.name === name) {
            return code;
        }
    }
    return null;
}

function showRegionInfoPanel(regionData) {
    const panel = document.getElementById('regionInfoPanel');
    const nameElement = document.getElementById('regionName');
    const detailsElement = document.getElementById('regionDetails');
    
    if (panel && nameElement && detailsElement) {
        nameElement.textContent = regionData.name;
        
        const campaigns = DataStore.getCampaignsByRegion(getRegionCodeByName(regionData.name));
        const activeCampaigns = campaigns.filter(c => c.status === 'active');
        
        detailsElement.innerHTML = `
            <div class="region-overview">
                <div class="overview-stats">
                    <div class="overview-stat">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-number">${formatNumber(regionData.population)}</span>
                            <span class="stat-label">Population</span>
                        </div>
                    </div>
                    
                    <div class="overview-stat">
                        <div class="stat-icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-number">${regionData.dropoutRate.overall}%</span>
                            <span class="stat-label">Dropout Rate</span>
                        </div>
                    </div>
                    
                    <div class="overview-stat">
                        <div class="stat-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-number">${regionData.literacyRate.overall}%</span>
                            <span class="stat-label">Literacy Rate</span>
                        </div>
                    </div>
                    
                    <div class="overview-stat">
                        <div class="stat-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-number">${activeCampaigns.length}</span>
                            <span class="stat-label">Active Campaigns</span>
                        </div>
                    </div>
                </div>
                
                <div class="demographics-info">
                    <h5>Demographics</h5>
                    <div class="demo-item">
                        <span>Rural Population:</span>
                        <span>${regionData.demographics.rural}%</span>
                    </div>
                    <div class="demo-item">
                        <span>Urban Population:</span>
                        <span>${regionData.demographics.urban}%</span>
                    </div>
                    <div class="demo-item">
                        <span>Below Poverty Line:</span>
                        <span>${regionData.demographics.belowPovertyLine}%</span>
                    </div>
                </div>
            </div>
        `;
        
        panel.classList.add('active');
    }
}

function showDetailedRegionInfo(regionCode, regionData) {
    // This would typically open a detailed modal or navigate to a detailed page
    // For now, we'll show an enhanced popup with more information
    
    const campaigns = DataStore.getCampaignsByRegion(regionCode);
    const trends = regionData.yearlyTrends;
    
    let detailsHTML = `
        <div class="detailed-region-info">
            <h3>${regionData.name} - Detailed Information</h3>
            
            <div class="detail-section">
                <h4>Education Statistics by Level</h4>
                <div class="level-stats">
                    <div class="level-stat">
                        <span class="level-name">Primary School:</span>
                        <span class="dropout-rate">Dropout: ${regionData.dropoutRate.primary}%</span>
                        <span class="enrollment-rate">Enrollment: ${regionData.enrollmentRate.primary}%</span>
                    </div>
                    <div class="level-stat">
                        <span class="level-name">Secondary School:</span>
                        <span class="dropout-rate">Dropout: ${regionData.dropoutRate.secondary}%</span>
                        <span class="enrollment-rate">Enrollment: ${regionData.enrollmentRate.secondary}%</span>
                    </div>
                    <div class="level-stat">
                        <span class="level-name">Higher Education:</span>
                        <span class="dropout-rate">Dropout: ${regionData.dropoutRate.higher}%</span>
                        <span class="enrollment-rate">Enrollment: ${regionData.enrollmentRate.higher}%</span>
                    </div>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Recent Trends (2021-2024)</h4>
                <div class="trend-chart">
                    ${Object.entries(trends).map(([year, data]) => `
                        <div class="trend-year">
                            <span class="year">${year}</span>
                            <span class="trend-dropout">Dropout: ${data.dropoutRate}%</span>
                            <span class="trend-literacy">Literacy: ${data.literacyRate}%</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Active Campaigns (${campaigns.filter(c => c.status === 'active').length})</h4>
                <div class="campaign-list">
                    ${campaigns.filter(c => c.status === 'active').map(campaign => `
                        <div class="campaign-item">
                            <span class="campaign-name">${campaign.name}</span>
                            <span class="campaign-type">${campaign.type}</span>
                            <span class="campaign-reach">${formatNumber(campaign.expectedReach)} people</span>
                        </div>
                    `).join('') || '<p>No active campaigns in this region.</p>'}
                </div>
            </div>
        </div>
    `;
    
    // Create and show modal (simplified implementation)
    showModal('Region Details', detailsHTML);
}

function showModal(title, content) {
    // Remove existing modal if present
    const existingModal = document.querySelector('.custom-modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'custom-modal active';
    modal.innerHTML = `
        <div class="modal-content large">
            <div class="modal-header">
                <h2>${title}</h2>
                <button class="close-modal" onclick="this.closest('.custom-modal').remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

function clearMarkers() {
    Object.values(regionMarkers).forEach(marker => {
        map.removeLayer(marker);
    });
    regionMarkers = {};
}

function initializeMapControls() {
    const dataLayerSelect = document.getElementById('dataLayer');
    const educationLevelSelect = document.getElementById('educationLevel');
    const yearFilterSelect = document.getElementById('yearFilter');
    const closePanelBtn = document.getElementById('closePanelBtn');
    
    // Data layer control
    if (dataLayerSelect) {
        dataLayerSelect.addEventListener('change', function() {
            currentLayer = this.value;
            updateMapDisplay();
            
            AuthManager.logActivity('map_layer_changed', {
                newLayer: currentLayer,
                educationLevel: currentEducationLevel
            });
        });
    }
    
    // Education level control
    if (educationLevelSelect) {
        educationLevelSelect.addEventListener('change', function() {
            currentEducationLevel = this.value;
            updateMapDisplay();
            
            AuthManager.logActivity('education_level_changed', {
                layer: currentLayer,
                newLevel: currentEducationLevel
            });
        });
    }
    
    // Year filter control
    if (yearFilterSelect) {
        yearFilterSelect.addEventListener('change', function() {
            currentYear = this.value;
            updateMapDisplay();
            
            AuthManager.logActivity('year_filter_changed', {
                newYear: currentYear
            });
        });
    }
    
    // Close panel button
    if (closePanelBtn) {
        closePanelBtn.addEventListener('click', function() {
            const panel = document.getElementById('regionInfoPanel');
            if (panel) {
                panel.classList.remove('active');
            }
        });
    }
}

function updateMapDisplay() {
    // Update legend
    updateLegend();
    
    // Redraw markers with new data
    displayRegionalMarkers();
}

function updateLegend() {
    const legend = document.querySelector('.map-legend');
    if (!legend) return;
    
    const legendTitle = legend.querySelector('h4');
    const legendItems = legend.querySelectorAll('.legend-item span');
    
    if (legendTitle) {
        let title = '';
        switch (currentLayer) {
            case 'dropout':
                title = `Dropout Rate (${currentEducationLevel.charAt(0).toUpperCase() + currentEducationLevel.slice(1)})`;
                break;
            case 'literacy':
                title = 'Literacy Rate (Overall)';
                break;
            case 'enrollment':
                title = `Enrollment Rate (${currentEducationLevel.charAt(0).toUpperCase() + currentEducationLevel.slice(1)})`;
                break;
        }
        legendTitle.textContent = title;
    }
    
    // Update legend labels based on current layer
    if (legendItems.length >= 4) {
        if (currentLayer === 'dropout') {
            legendItems[0].textContent = 'High Risk (>20%)';
            legendItems[1].textContent = 'Medium Risk (15-20%)';
            legendItems[2].textContent = 'Low Risk (10-15%)';
            legendItems[3].textContent = 'Very Low (<10%)';
        } else {
            legendItems[0].textContent = 'Excellent (>80%)';
            legendItems[1].textContent = 'Good (70-80%)';
            legendItems[2].textContent = 'Fair (60-70%)';
            legendItems[3].textContent = 'Needs Improvement (<60%)';
        }
    }
}

function initializeRegionSearch() {
    const searchInput = document.getElementById('regionSearch');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            searchRegions(searchTerm);
        });
        
        // Add search suggestions
        addSearchSuggestions(searchInput);
    }
}

function searchRegions(searchTerm) {
    if (!searchTerm) {
        // Reset all markers to normal state
        Object.values(regionMarkers).forEach(marker => {
            marker.setStyle({
                fillOpacity: 0.8,
                weight: 2
            });
        });
        return;
    }
    
    Object.entries(mapData).forEach(([regionCode, regionData]) => {
        const marker = regionMarkers[regionCode];
        if (marker) {
            if (regionData.name.toLowerCase().includes(searchTerm)) {
                // Highlight matching regions
                marker.setStyle({
                    fillOpacity: 1,
                    weight: 4
                });
                
                // If exact match, center map on region
                if (regionData.name.toLowerCase() === searchTerm) {
                    map.setView(regionData.coordinates, 7);
                    marker.openPopup();
                }
            } else {
                // Dim non-matching regions
                marker.setStyle({
                    fillOpacity: 0.3,
                    weight: 1
                });
            }
        }
    });
}

function addSearchSuggestions(searchInput) {
    const suggestionsList = document.createElement('ul');
    suggestionsList.className = 'search-suggestions';
    searchInput.parentNode.appendChild(suggestionsList);
    
    searchInput.addEventListener('focus', function() {
        showSearchSuggestions(suggestionsList);
    });
    
    searchInput.addEventListener('blur', function() {
        // Hide suggestions after a short delay to allow clicking
        setTimeout(() => {
            suggestionsList.style.display = 'none';
        }, 200);
    });
}

function showSearchSuggestions(suggestionsList) {
    const regions = Object.values(mapData).map(region => region.name);
    
    suggestionsList.innerHTML = regions.map(regionName => `
        <li class="suggestion-item" onclick="selectRegion('${regionName}')">${regionName}</li>
    `).join('');
    
    suggestionsList.style.display = 'block';
}

function selectRegion(regionName) {
    const searchInput = document.getElementById('regionSearch');
    const regionCode = getRegionCodeByName(regionName);
    
    if (searchInput && regionCode) {
        searchInput.value = regionName;
        
        const regionData = mapData[regionCode];
        const marker = regionMarkers[regionCode];
        
        if (marker && regionData) {
            map.setView(regionData.coordinates, 7);
            marker.openPopup();
            showRegionInfoPanel(regionData);
        }
        
        // Hide suggestions
        const suggestionsList = document.querySelector('.search-suggestions');
        if (suggestionsList) {
            suggestionsList.style.display = 'none';
        }
    }
}

// Add custom styles for map components
const mapStyles = `
    .map-popup {
        min-width: 250px;
    }
    
    .popup-stats {
        margin: 12px 0;
    }
    
    .stat-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
    }
    
    .stat-label {
        font-weight: 500;
        color: var(--gray-700);
    }
    
    .stat-value {
        font-weight: 600;
    }
    
    .stat-value.high-risk {
        color: var(--danger-color);
    }
    
    .stat-value.low-risk,
    .stat-value.good {
        color: var(--success-color);
    }
    
    .stat-value.needs-improvement {
        color: var(--warning-color);
    }
    
    .popup-actions {
        margin-top: 12px;
        text-align: center;
    }
    
    .btn-primary {
        background: var(--primary-color);
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 12px;
        font-weight: 500;
    }
    
    .btn-primary:hover {
        background: var(--primary-dark);
    }
    
    .overview-stats {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
        margin-bottom: 20px;
    }
    
    .overview-stat {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px;
        background: var(--gray-50);
        border-radius: 6px;
    }
    
    .stat-icon {
        width: 32px;
        height: 32px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--primary-color);
        color: white;
        font-size: 14px;
    }
    
    .stat-info {
        display: flex;
        flex-direction: column;
    }
    
    .stat-number {
        font-size: 16px;
        font-weight: 600;
        color: var(--gray-900);
    }
    
    .stat-label {
        font-size: 11px;
        color: var(--gray-600);
    }
    
    .demographics-info h5 {
        margin-bottom: 8px;
        color: var(--gray-900);
        font-size: 14px;
    }
    
    .demo-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 6px;
        font-size: 12px;
        color: var(--gray-700);
    }
    
    .search-suggestions {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid var(--gray-200);
        border-radius: 0 0 6px 6px;
        max-height: 200px;
        overflow-y: auto;
        z-index: 1000;
        display: none;
        margin: 0;
        padding: 0;
        list-style: none;
        box-shadow: var(--shadow-md);
    }
    
    .suggestion-item {
        padding: 10px 12px;
        cursor: pointer;
        border-bottom: 1px solid var(--gray-100);
        font-size: 13px;
    }
    
    .suggestion-item:hover {
        background: var(--gray-50);
    }
    
    .suggestion-item:last-child {
        border-bottom: none;
    }
    
    .custom-modal .modal-body {
        padding: 24px;
        max-height: 70vh;
        overflow-y: auto;
    }
    
    .detailed-region-info h3 {
        margin-bottom: 20px;
        color: var(--gray-900);
    }
    
    .detail-section {
        margin-bottom: 24px;
    }
    
    .detail-section h4 {
        margin-bottom: 12px;
        color: var(--gray-800);
        font-size: 16px;
    }
    
    .level-stats {
        display: grid;
        gap: 8px;
    }
    
    .level-stat {
        display: grid;
        grid-template-columns: 1fr auto auto;
        gap: 16px;
        padding: 12px;
        background: var(--gray-50);
        border-radius: 6px;
        font-size: 13px;
    }
    
    .level-name {
        font-weight: 500;
        color: var(--gray-900);
    }
    
    .trend-chart {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 12px;
    }
    
    .trend-year {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 12px;
        background: var(--gray-50);
        border-radius: 6px;
        text-align: center;
        font-size: 12px;
    }
    
    .year {
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .campaign-list {
        display: grid;
        gap: 8px;
    }
    
    .campaign-item {
        display: grid;
        grid-template-columns: 1fr auto auto;
        gap: 12px;
        padding: 10px;
        background: var(--gray-50);
        border-radius: 6px;
        font-size: 12px;
        align-items: center;
    }
    
    .campaign-name {
        font-weight: 500;
        color: var(--gray-900);
    }
    
    .campaign-type {
        background: var(--primary-color);
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 10px;
        text-transform: uppercase;
    }
    
    .search-box {
        position: relative;
    }
`;

// Add map styles to document
const mapStyleSheet = document.createElement('style');
mapStyleSheet.textContent = mapStyles;
document.head.appendChild(mapStyleSheet);