// Analysis dashboard functionality with charts and statistics

let charts = {};
let currentTimeRange = '1year';

// Initialize analysis dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.charts-grid')) {
        initializeAnalysisDashboard();
    }
});

function initializeAnalysisDashboard() {
    loadNationalStatistics();
    initializeCharts();
    initializeDataTable();
    initializeControls();
    
    // Log dashboard access
    AuthManager.logActivity('analysis_dashboard_loaded', {
        timeRange: currentTimeRange,
        timestamp: new Date().toISOString()
    });
}

function loadNationalStatistics() {
    const nationalStats = DataStore.getNationalStats();
    
    // Update overview statistics
    updateStatCard('totalStudents', formatNumber(nationalStats.totalStudents), '+2.3%', 'positive');
    updateStatCard('dropoutRate', nationalStats.overallDropoutRate + '%', '-0.8%', 'negative');
    updateStatCard('literacyRate', nationalStats.overallLiteracyRate + '%', '+1.2%', 'positive');
    updateStatCard('activeCampaigns', nationalStats.activeCampaigns, '+4', 'positive');
}

function updateStatCard(elementId, value, change, changeType) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = value;
        
        // Update change indicator if it exists
        const changeElement = element.parentNode.querySelector('.stat-change');
        if (changeElement) {
            changeElement.textContent = change;
            changeElement.className = `stat-change ${changeType}`;
        }
    }
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function initializeCharts() {
    initializeDropoutTrendChart();
    initializeRegionalComparisonChart();
    initializeGenderChart();
    initializeAgeGroupChart();
}

function initializeDropoutTrendChart() {
    const ctx = document.getElementById('dropoutTrendChart');
    if (!ctx) return;
    
    const monthlyTrends = DataStore.getMonthlyTrends();
    
    charts.dropoutTrend = new Chart(ctx, {
        type: 'line',
        data: {
            labels: monthlyTrends.dropoutRate.map(item => item.month),
            datasets: [
                {
                    label: 'Dropout Rate (%)',
                    data: monthlyTrends.dropoutRate.map(item => item.value),
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#ef4444',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                },
                {
                    label: 'Literacy Rate (%)',
                    data: monthlyTrends.literacyRate.map(item => item.value),
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#10b981',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                },
                {
                    label: 'Enrollment Rate (%)',
                    data: monthlyTrends.enrollment.map(item => item.value),
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#3b82f6',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            family: 'Inter',
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#374151',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: true,
                    intersect: false,
                    mode: 'index'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(156, 163, 175, 0.2)'
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        },
                        font: {
                            family: 'Inter',
                            size: 11
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(156, 163, 175, 0.2)'
                    },
                    ticks: {
                        font: {
                            family: 'Inter',
                            size: 11
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

function initializeRegionalComparisonChart() {
    const ctx = document.getElementById('regionalComparisonChart');
    if (!ctx) return;
    
    const regionalData = DataStore.getRegionalData();
    const regions = Object.values(regionalData).slice(0, 8); // Show top 8 regions
    
    charts.regionalComparison = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: regions.map(region => region.name),
            datasets: [
                {
                    label: 'Dropout Rate (%)',
                    data: regions.map(region => region.dropoutRate.overall),
                    backgroundColor: 'rgba(239, 68, 68, 0.7)',
                    borderColor: '#ef4444',
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                },
                {
                    label: 'Literacy Rate (%)',
                    data: regions.map(region => region.literacyRate.overall),
                    backgroundColor: 'rgba(16, 185, 129, 0.7)',
                    borderColor: '#10b981',
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            family: 'Inter',
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#374151',
                    borderWidth: 1,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(156, 163, 175, 0.2)'
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        },
                        font: {
                            family: 'Inter',
                            size: 11
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        maxRotation: 45,
                        font: {
                            family: 'Inter',
                            size: 10
                        }
                    }
                }
            }
        }
    });
}

function initializeGenderChart() {
    const ctx = document.getElementById('genderChart');
    if (!ctx) return;
    
    const genderData = DataStore.getGenderData();
    
    charts.gender = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [
                'Male Dropout Rate',
                'Female Dropout Rate',
                'Male Literacy Rate',
                'Female Literacy Rate'
            ],
            datasets: [{
                data: [
                    genderData.male.dropoutRate,
                    genderData.female.dropoutRate,
                    genderData.male.literacyRate,
                    genderData.female.literacyRate
                ],
                backgroundColor: [
                    '#ef4444',
                    '#f87171',
                    '#10b981',
                    '#34d399'
                ],
                borderColor: '#ffffff',
                borderWidth: 3,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            family: 'Inter',
                            size: 11
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#374151',
                    borderWidth: 1,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '%';
                        }
                    }
                }
            },
            cutout: '60%'
        }
    });
}

function initializeAgeGroupChart() {
    const ctx = document.getElementById('ageGroupChart');
    if (!ctx) return;
    
    const ageGroupData = DataStore.getAgeGroupData();
    const ageGroups = Object.keys(ageGroupData);
    
    charts.ageGroup = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ageGroups,
            datasets: [
                {
                    label: 'Dropout Rate (%)',
                    data: ageGroups.map(group => ageGroupData[group].dropoutRate),
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.2)',
                    pointBackgroundColor: '#ef4444',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    borderWidth: 2
                },
                {
                    label: 'Enrollment Rate (%)',
                    data: ageGroups.map(group => ageGroupData[group].enrollmentRate),
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.2)',
                    pointBackgroundColor: '#10b981',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            family: 'Inter',
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#374151',
                    borderWidth: 1,
                    cornerRadius: 8
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(156, 163, 175, 0.2)'
                    },
                    angleLines: {
                        color: 'rgba(156, 163, 175, 0.2)'
                    },
                    pointLabels: {
                        font: {
                            family: 'Inter',
                            size: 10
                        }
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        },
                        font: {
                            family: 'Inter',
                            size: 9
                        }
                    }
                }
            }
        }
    });
}

function initializeDataTable() {
    const tableBody = document.getElementById('regionTableBody');
    if (!tableBody) return;
    
    const regionalData = DataStore.getRegionalData();
    const campaigns = DataStore.getCampaignsData();
    
    let tableHTML = '';
    Object.entries(regionalData).forEach(([regionCode, region]) => {
        const regionCampaigns = campaigns.filter(c => c.region === regionCode);
        const activeCampaigns = regionCampaigns.filter(c => c.status === 'active').length;
        
        tableHTML += `
            <tr data-region="${regionCode}">
                <td>
                    <div class="region-name">
                        <strong>${region.name}</strong>
                        <span class="region-code">${regionCode}</span>
                    </div>
                </td>
                <td>${formatNumber(region.population)}</td>
                <td>
                    <span class="rate-badge ${region.dropoutRate.overall > 15 ? 'high' : 'low'}">
                        ${region.dropoutRate.overall}%
                    </span>
                </td>
                <td>
                    <span class="rate-badge ${region.literacyRate.overall > 75 ? 'high' : 'low'}">
                        ${region.literacyRate.overall}%
                    </span>
                </td>
                <td>
                    <span class="rate-badge ${region.enrollmentRate.primary > 90 ? 'high' : 'low'}">
                        ${region.enrollmentRate.primary}%
                    </span>
                </td>
                <td>
                    <span class="campaign-count">${activeCampaigns}</span>
                </td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = tableHTML;
}

function initializeControls() {
    // Time range filter
    const timeRangeSelect = document.getElementById('timeRange');
    if (timeRangeSelect) {
        timeRangeSelect.addEventListener('change', function() {
            currentTimeRange = this.value;
            updateChartsData();
            
            AuthManager.logActivity('time_range_changed', {
                newRange: currentTimeRange
            });
        });
    }
    
    // Trend filter
    const trendFilterSelect = document.getElementById('trendFilter');
    if (trendFilterSelect) {
        trendFilterSelect.addEventListener('change', function() {
            updateTrendChart(this.value);
            
            AuthManager.logActivity('trend_filter_changed', {
                newFilter: this.value
            });
        });
    }
    
    // Region filter
    const regionFilterSelect = document.getElementById('regionFilter');
    if (regionFilterSelect) {
        regionFilterSelect.addEventListener('change', function() {
            updateRegionalChart(this.value);
            
            AuthManager.logActivity('region_filter_changed', {
                newFilter: this.value
            });
        });
    }
    
    // Table search
    const tableSearchInput = document.getElementById('tableSearch');
    if (tableSearchInput) {
        tableSearchInput.addEventListener('input', function() {
            filterTable(this.value);
        });
    }
    
    // Export data button
    const exportButton = document.getElementById('exportData');
    if (exportButton) {
        exportButton.addEventListener('click', exportTableData);
    }
}

function updateChartsData() {
    // Update charts based on selected time range
    // This would typically fetch new data from an API
    // For demo purposes, we'll simulate different data
    
    loadNationalStatistics();
    
    // Simulate different trend data based on time range
    if (charts.dropoutTrend) {
        const newData = generateTrendData(currentTimeRange);
        charts.dropoutTrend.data.labels = newData.labels;
        charts.dropoutTrend.data.datasets[0].data = newData.dropout;
        charts.dropoutTrend.data.datasets[1].data = newData.literacy;
        charts.dropoutTrend.data.datasets[2].data = newData.enrollment;
        charts.dropoutTrend.update();
    }
}

function generateTrendData(timeRange) {
    // Generate sample data based on time range
    let labels = [];
    let dropout = [];
    let literacy = [];
    let enrollment = [];
    
    switch (timeRange) {
        case '1year':
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
            dropout = [13.2, 12.9, 12.7, 12.5, 12.4, 12.2];
            literacy = [77.8, 78.0, 78.2, 78.4, 78.5, 78.6];
            enrollment = [86.2, 86.8, 87.1, 87.5, 87.8, 88.0];
            break;
        case '3years':
            labels = ['2022', '2023', '2024'];
            dropout = [13.5, 12.9, 12.4];
            literacy = [77.0, 77.8, 78.6];
            enrollment = [85.2, 86.5, 88.0];
            break;
        case '5years':
            labels = ['2020', '2021', '2022', '2023', '2024'];
            dropout = [15.1, 14.2, 13.5, 12.9, 12.4];
            literacy = [75.2, 76.1, 77.0, 77.8, 78.6];
            enrollment = [82.1, 83.5, 85.2, 86.5, 88.0];
            break;
    }
    
    return { labels, dropout, literacy, enrollment };
}

function updateTrendChart(filter) {
    // Update trend chart based on filter (monthly, quarterly, yearly)
    if (charts.dropoutTrend) {
        const newData = generateTrendData(filter === 'yearly' ? '5years' : '1year');
        charts.dropoutTrend.data.labels = newData.labels;
        charts.dropoutTrend.data.datasets[0].data = newData.dropout;
        charts.dropoutTrend.data.datasets[1].data = newData.literacy;
        charts.dropoutTrend.data.datasets[2].data = newData.enrollment;
        charts.dropoutTrend.update();
    }
}

function updateRegionalChart(filter) {
    if (!charts.regionalComparison) return;
    
    const regionalData = DataStore.getRegionalData();
    let regions = Object.values(regionalData);
    
    // Filter regions based on selection
    if (filter !== 'all') {
        const regionMap = {
            'north': ['uttar-pradesh', 'bihar', 'rajasthan'],
            'south': ['tamil-nadu', 'karnataka', 'kerala'],
            'east': ['west-bengal'],
            'west': ['maharashtra', 'gujarat', 'madhya-pradesh']
        };
        
        if (regionMap[filter]) {
            regions = regions.filter(region => {
                const regionCode = Object.keys(regionalData).find(code => 
                    regionalData[code].name === region.name
                );
                return regionMap[filter].includes(regionCode);
            });
        }
    }
    
    // Limit to 8 regions for readability
    regions = regions.slice(0, 8);
    
    charts.regionalComparison.data.labels = regions.map(region => region.name);
    charts.regionalComparison.data.datasets[0].data = regions.map(region => region.dropoutRate.overall);
    charts.regionalComparison.data.datasets[1].data = regions.map(region => region.literacyRate.overall);
    charts.regionalComparison.update();
}

function filterTable(searchTerm) {
    const tableRows = document.querySelectorAll('#regionTable tbody tr');
    
    tableRows.forEach(row => {
        const regionName = row.querySelector('.region-name strong').textContent.toLowerCase();
        const regionCode = row.querySelector('.region-code').textContent.toLowerCase();
        
        if (regionName.includes(searchTerm.toLowerCase()) || 
            regionCode.includes(searchTerm.toLowerCase())) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
    
    // Log search activity
    if (searchTerm) {
        AuthManager.logActivity('table_search', {
            searchTerm: searchTerm
        });
    }
}

function exportTableData() {
    const regionalData = DataStore.getRegionalData();
    const campaigns = DataStore.getCampaignsData();
    
    // Prepare CSV data
    let csvContent = "Region,Population,Dropout Rate (%),Literacy Rate (%),Enrollment Rate (%),Active Campaigns\n";
    
    Object.entries(regionalData).forEach(([regionCode, region]) => {
        const regionCampaigns = campaigns.filter(c => c.region === regionCode);
        const activeCampaigns = regionCampaigns.filter(c => c.status === 'active').length;
        
        csvContent += `"${region.name}",${region.population},${region.dropoutRate.overall},${region.literacyRate.overall},${region.enrollmentRate.primary},${activeCampaigns}\n`;
    });
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `regional_statistics_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Log export activity
    AuthManager.logActivity('data_exported', {
        format: 'csv',
        dataType: 'regional_statistics',
        timestamp: new Date().toISOString()
    });
}

// Add analysis-specific styles
const analysisStyles = `
    .region-name {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }
    
    .region-code {
        font-size: 11px;
        color: var(--gray-500);
        font-weight: normal;
    }
    
    .rate-badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .rate-badge.high {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success-color);
    }
    
    .rate-badge.low {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger-color);
    }
    
    .campaign-count {
        display: inline-block;
        background: var(--primary-color);
        color: white;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        min-width: 20px;
        text-align: center;
    }
    
    .chart-content canvas {
        max-height: 400px;
    }
    
    /* Chart responsive adjustments */
    @media (max-width: 768px) {
        .charts-grid {
            grid-template-columns: 1fr;
        }
        
        .chart-content canvas {
            max-height: 300px;
        }
        
        .stats-overview {
            grid-template-columns: 1fr;
        }
        
        .table-wrapper {
            overflow-x: auto;
        }
        
        .data-table {
            min-width: 600px;
        }
    }
`;

// Add analysis styles to document
const analysisStyleSheet = document.createElement('style');
analysisStyleSheet.textContent = analysisStyles;
document.head.appendChild(analysisStyleSheet);

// Cleanup function for charts when navigating away
window.addEventListener('beforeunload', function() {
    Object.values(charts).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });
});

// Handle window resize for responsive charts
window.addEventListener('resize', function() {
    Object.values(charts).forEach(chart => {
        if (chart && typeof chart.resize === 'function') {
            setTimeout(() => {
                chart.resize();
            }, 100);
        }
    });
});