// Comprehensive data store for the School Dropout & Literacy Rate Tracker

// Regional data with comprehensive statistics
const regionalData = {
    'uttar-pradesh': {
        name: 'Uttar Pradesh',
        population: 199812341,
        coordinates: [26.8467, 80.9462],
        dropoutRate: {
            primary: 18.5,
            secondary: 22.3,
            higher: 15.2,
            overall: 18.7
        },
        literacyRate: {
            male: 79.2,
            female: 59.3,
            overall: 67.7
        },
        enrollmentRate: {
            primary: 94.2,
            secondary: 78.5,
            higher: 52.3
        },
        demographics: {
            rural: 77.7,
            urban: 22.3,
            belowPovertyLine: 29.4
        },
        activeCampaigns: 8,
        yearlyTrends: {
            2021: { dropoutRate: 20.1, literacyRate: 65.2 },
            2022: { dropoutRate: 19.3, literacyRate: 66.1 },
            2023: { dropoutRate: 18.9, literacyRate: 67.0 },
            2024: { dropoutRate: 18.7, literacyRate: 67.7 }
        }
    },
    'maharashtra': {
        name: 'Maharashtra',
        population: 112374333,
        coordinates: [19.7515, 75.7139],
        dropoutRate: {
            primary: 8.2,
            secondary: 12.1,
            higher: 9.8,
            overall: 10.0
        },
        literacyRate: {
            male: 89.8,
            female: 75.9,
            overall: 82.3
        },
        enrollmentRate: {
            primary: 98.1,
            secondary: 89.2,
            higher: 67.8
        },
        demographics: {
            rural: 54.8,
            urban: 45.2,
            belowPovertyLine: 17.4
        },
        activeCampaigns: 12,
        yearlyTrends: {
            2021: { dropoutRate: 11.2, literacyRate: 80.1 },
            2022: { dropoutRate: 10.8, literacyRate: 81.0 },
            2023: { dropoutRate: 10.4, literacyRate: 81.7 },
            2024: { dropoutRate: 10.0, literacyRate: 82.3 }
        }
    },
    'bihar': {
        name: 'Bihar',
        population: 104099452,
        coordinates: [25.0961, 85.3131],
        dropoutRate: {
            primary: 25.3,
            secondary: 31.2,
            higher: 22.8,
            overall: 26.4
        },
        literacyRate: {
            male: 73.4,
            female: 53.3,
            overall: 61.8
        },
        enrollmentRate: {
            primary: 87.3,
            secondary: 65.2,
            higher: 34.1
        },
        demographics: {
            rural: 88.1,
            urban: 11.9,
            belowPovertyLine: 33.7
        },
        activeCampaigns: 6,
        yearlyTrends: {
            2021: { dropoutRate: 28.9, literacyRate: 58.4 },
            2022: { dropoutRate: 27.8, literacyRate: 59.8 },
            2023: { dropoutRate: 27.1, literacyRate: 60.9 },
            2024: { dropoutRate: 26.4, literacyRate: 61.8 }
        }
    },
    'west-bengal': {
        name: 'West Bengal',
        population: 91276115,
        coordinates: [22.9868, 87.8550],
        dropoutRate: {
            primary: 14.7,
            secondary: 18.9,
            higher: 12.3,
            overall: 15.3
        },
        literacyRate: {
            male: 82.7,
            female: 71.2,
            overall: 76.3
        },
        enrollmentRate: {
            primary: 96.8,
            secondary: 82.4,
            higher: 58.7
        },
        demographics: {
            rural: 68.1,
            urban: 31.9,
            belowPovertyLine: 19.9
        },
        activeCampaigns: 9,
        yearlyTrends: {
            2021: { dropoutRate: 17.2, literacyRate: 74.1 },
            2022: { dropoutRate: 16.4, literacyRate: 75.0 },
            2023: { dropoutRate: 15.8, literacyRate: 75.7 },
            2024: { dropoutRate: 15.3, literacyRate: 76.3 }
        }
    },
    'madhya-pradesh': {
        name: 'Madhya Pradesh',
        population: 72626809,
        coordinates: [22.9734, 78.6569],
        dropoutRate: {
            primary: 21.4,
            secondary: 26.8,
            higher: 18.9,
            overall: 22.4
        },
        literacyRate: {
            male: 78.7,
            female: 60.0,
            overall: 69.3
        },
        enrollmentRate: {
            primary: 91.5,
            secondary: 74.2,
            higher: 49.8
        },
        demographics: {
            rural: 72.4,
            urban: 27.6,
            belowPovertyLine: 31.6
        },
        activeCampaigns: 5,
        yearlyTrends: {
            2021: { dropoutRate: 24.7, literacyRate: 67.1 },
            2022: { dropoutRate: 23.8, literacyRate: 68.0 },
            2023: { dropoutRate: 23.1, literacyRate: 68.7 },
            2024: { dropoutRate: 22.4, literacyRate: 69.3 }
        }
    },
    'tamil-nadu': {
        name: 'Tamil Nadu',
        population: 72147030,
        coordinates: [11.1271, 78.6569],
        dropoutRate: {
            primary: 4.2,
            secondary: 7.8,
            higher: 5.9,
            overall: 5.9
        },
        literacyRate: {
            male: 86.8,
            female: 73.9,
            overall: 80.1
        },
        enrollmentRate: {
            primary: 99.2,
            secondary: 94.1,
            higher: 78.4
        },
        demographics: {
            rural: 51.6,
            urban: 48.4,
            belowPovertyLine: 11.3
        },
        activeCampaigns: 15,
        yearlyTrends: {
            2021: { dropoutRate: 6.8, literacyRate: 78.3 },
            2022: { dropoutRate: 6.4, literacyRate: 79.0 },
            2023: { dropoutRate: 6.1, literacyRate: 79.6 },
            2024: { dropoutRate: 5.9, literacyRate: 80.1 }
        }
    },
    'rajasthan': {
        name: 'Rajasthan',
        population: 68548437,
        coordinates: [27.0238, 74.2179],
        dropoutRate: {
            primary: 16.8,
            secondary: 21.4,
            higher: 14.7,
            overall: 17.6
        },
        literacyRate: {
            male: 80.5,
            female: 52.7,
            overall: 66.1
        },
        enrollmentRate: {
            primary: 93.7,
            secondary: 78.9,
            higher: 54.2
        },
        demographics: {
            rural: 75.1,
            urban: 24.9,
            belowPovertyLine: 16.4
        },
        activeCampaigns: 7,
        yearlyTrends: {
            2021: { dropoutRate: 19.4, literacyRate: 64.2 },
            2022: { dropoutRate: 18.7, literacyRate: 64.9 },
            2023: { dropoutRate: 18.1, literacyRate: 65.5 },
            2024: { dropoutRate: 17.6, literacyRate: 66.1 }
        }
    },
    'karnataka': {
        name: 'Karnataka',
        population: 61095297,
        coordinates: [15.3173, 75.7139],
        dropoutRate: {
            primary: 7.3,
            secondary: 11.2,
            higher: 8.4,
            overall: 8.9
        },
        literacyRate: {
            male: 82.8,
            female: 68.1,
            overall: 75.4
        },
        enrollmentRate: {
            primary: 97.8,
            secondary: 88.6,
            higher: 71.3
        },
        demographics: {
            rural: 61.4,
            urban: 38.6,
            belowPovertyLine: 20.9
        },
        activeCampaigns: 11,
        yearlyTrends: {
            2021: { dropoutRate: 10.1, literacyRate: 73.2 },
            2022: { dropoutRate: 9.6, literacyRate: 74.1 },
            2023: { dropoutRate: 9.2, literacyRate: 74.8 },
            2024: { dropoutRate: 8.9, literacyRate: 75.4 }
        }
    },
    'gujarat': {
        name: 'Gujarat',
        population: 60439692,
        coordinates: [22.2587, 71.1924],
        dropoutRate: {
            primary: 9.1,
            secondary: 13.7,
            higher: 10.2,
            overall: 11.0
        },
        literacyRate: {
            male: 87.2,
            female: 70.7,
            overall: 78.0
        },
        enrollmentRate: {
            primary: 96.4,
            secondary: 85.8,
            higher: 66.9
        },
        demographics: {
            rural: 57.4,
            urban: 42.6,
            belowPovertyLine: 16.6
        },
        activeCampaigns: 10,
        yearlyTrends: {
            2021: { dropoutRate: 12.4, literacyRate: 76.1 },
            2022: { dropoutRate: 11.9, literacyRate: 76.8 },
            2023: { dropoutRate: 11.4, literacyRate: 77.4 },
            2024: { dropoutRate: 11.0, literacyRate: 78.0 }
        }
    },
    'kerala': {
        name: 'Kerala',
        population: 33406061,
        coordinates: [10.8505, 76.2711],
        dropoutRate: {
            primary: 1.8,
            secondary: 2.9,
            higher: 2.1,
            overall: 2.1
        },
        literacyRate: {
            male: 96.1,
            female: 92.1,
            overall: 94.0
        },
        enrollmentRate: {
            primary: 99.8,
            secondary: 97.2,
            higher: 89.4
        },
        demographics: {
            rural: 52.3,
            urban: 47.7,
            belowPovertyLine: 7.0
        },
        activeCampaigns: 3,
        yearlyTrends: {
            2021: { dropoutRate: 2.7, literacyRate: 92.8 },
            2022: { dropoutRate: 2.4, literacyRate: 93.2 },
            2023: { dropoutRate: 2.2, literacyRate: 93.6 },
            2024: { dropoutRate: 2.1, literacyRate: 94.0 }
        }
    }
};

// Campaign data
const campaignsData = [
    {
        id: 1,
        name: "Back to School Initiative",
        type: "enrollment",
        description: "Comprehensive program to bring out-of-school children back to education through community engagement and incentive programs.",
        region: "uttar-pradesh",
        targetAudience: "students",
        status: "active",
        startDate: "2024-01-15",
        endDate: "2024-12-31",
        budget: 2500000,
        expectedReach: 150000,
        actualReach: 87500,
        successRate: 68,
        createdBy: "ngo",
        createdDate: "2023-12-01",
        activities: [
            "Door-to-door surveys to identify out-of-school children",
            "Community meetings with parents and guardians",
            "Provision of school supplies and uniforms",
            "Transportation support in remote areas"
        ],
        metrics: {
            childrenEnrolled: 87500,
            familiesReached: 45000,
            communityMeetings: 230,
            schoolsPartnered: 125
        }
    },
    {
        id: 2,
        name: "Digital Literacy for All",
        type: "literacy",
        description: "Technology-driven literacy program focusing on basic digital skills and computer literacy for youth and adults.",
        region: "bihar",
        targetAudience: "all",
        status: "active",
        startDate: "2024-03-01",
        endDate: "2024-08-31",
        budget: 1800000,
        expectedReach: 80000,
        actualReach: 52000,
        successRate: 75,
        createdBy: "ngo",
        createdDate: "2024-01-15",
        activities: [
            "Setting up mobile computer labs",
            "Training local instructors",
            "Basic computer and internet training",
            "Digital literacy assessment and certification"
        ],
        metrics: {
            peopleTrained: 52000,
            certificatesIssued: 39000,
            mobileLabs: 15,
            instructorsTrained: 85
        }
    },
    {
        id: 3,
        name: "Girls Education Empowerment",
        type: "awareness",
        description: "Targeted campaign to promote girls' education and address cultural barriers to female literacy in rural areas.",
        region: "rajasthan",
        targetAudience: "parents",
        status: "active",
        startDate: "2024-02-01",
        endDate: "2024-11-30",
        budget: 3200000,
        expectedReach: 200000,
        actualReach: 145000,
        successRate: 82,
        createdBy: "ngo",
        createdDate: "2023-11-20",
        activities: [
            "Community awareness campaigns",
            "Scholarships for girl students",
            "Safety measures implementation",
            "Women's education success story sharing"
        ],
        metrics: {
            girlsEnrolled: 25000,
            scholarshipsProvided: 5000,
            awarenessEvents: 180,
            communityLeadersEngaged: 350
        }
    },
    {
        id: 4,
        name: "Skill Development for Dropouts",
        type: "retention",
        description: "Vocational training program for school dropouts to provide alternative education pathways and employment opportunities.",
        region: "west-bengal",
        targetAudience: "students",
        status: "planned",
        startDate: "2024-07-01",
        endDate: "2025-06-30",
        budget: 4500000,
        expectedReach: 75000,
        actualReach: 0,
        successRate: 0,
        createdBy: "ngo",
        createdDate: "2024-04-10",
        activities: [
            "Vocational skill assessment",
            "Trade-specific training programs",
            "Industry partnerships for placements",
            "Entrepreneurship development workshops"
        ],
        metrics: {
            skillsTraining: 0,
            jobPlacements: 0,
            industryPartnerships: 12,
            trainingCenters: 8
        }
    },
    {
        id: 5,
        name: "Mid-Day Meal Enhancement",
        type: "retention",
        description: "Improving quality and reach of mid-day meal programs to increase school attendance and reduce dropout rates.",
        region: "madhya-pradesh",
        targetAudience: "students",
        status: "active",
        startDate: "2024-01-01",
        endDate: "2024-12-31",
        budget: 5800000,
        expectedReach: 300000,
        actualReach: 275000,
        successRate: 88,
        createdBy: "ngo",
        createdDate: "2023-10-15",
        activities: [
            "Nutritional meal planning",
            "Kitchen infrastructure improvement",
            "Local sourcing of ingredients",
            "Monitoring and quality control"
        ],
        metrics: {
            studentsServed: 275000,
            mealsProvided: 48000000,
            kitchensUpgraded: 450,
            nutritionImprovement: 78
        }
    },
    {
        id: 6,
        name: "Teacher Training Excellence",
        type: "awareness",
        description: "Comprehensive teacher training program to improve teaching quality and reduce student disengagement.",
        region: "tamil-nadu",
        targetAudience: "teachers",
        status: "completed",
        startDate: "2023-08-01",
        endDate: "2024-03-31",
        budget: 2200000,
        expectedReach: 5000,
        actualReach: 4800,
        successRate: 92,
        createdBy: "ngo",
        createdDate: "2023-06-01",
        activities: [
            "Pedagogy and methodology training",
            "Technology integration workshops",
            "Student psychology understanding",
            "Classroom management techniques"
        ],
        metrics: {
            teachersTrained: 4800,
            workshopsConducted: 96,
            certificationRate: 92,
            studentSatisfactionImprovement: 85
        }
    },
    {
        id: 7,
        name: "Community Learning Centers",
        type: "literacy",
        description: "Establishing community-based learning centers in remote areas to provide basic education and adult literacy programs.",
        region: "karnataka",
        targetAudience: "community",
        status: "active",
        startDate: "2024-04-01",
        endDate: "2025-03-31",
        budget: 3800000,
        expectedReach: 120000,
        actualReach: 68000,
        successRate: 71,
        createdBy: "ngo",
        createdDate: "2024-02-01",
        activities: [
            "Setting up learning centers",
            "Recruiting local educators",
            "Developing curriculum materials",
            "Community outreach programs"
        ],
        metrics: {
            centersEstablished: 45,
            adultLearners: 28000,
            childrenEnrolled: 40000,
            educatorsHired: 180
        }
    },
    {
        id: 8,
        name: "Parent Engagement Initiative",
        type: "awareness",
        description: "Engaging parents and guardians in the education process to reduce dropouts and improve learning outcomes.",
        region: "gujarat",
        targetAudience: "parents",
        status: "active",
        startDate: "2024-05-01",
        endDate: "2024-10-31",
        budget: 1200000,
        expectedReach: 100000,
        actualReach: 78000,
        successRate: 79,
        createdBy: "ngo",
        createdDate: "2024-03-15",
        activities: [
            "Parent-teacher meetings",
            "Home learning support training",
            "Education importance awareness",
            "Community education committees"
        ],
        metrics: {
            parentsEngaged: 78000,
            meetingsConducted: 320,
            committeesFormed: 156,
            attendanceImprovement: 23
        }
    }
];

// National overview statistics
const nationalStats = {
    totalStudents: 2450000,
    overallDropoutRate: 12.4,
    overallLiteracyRate: 78.6,
    activeCampaigns: 24,
    totalCampaigns: 32,
    peopleReached: 1200000,
    campaignSuccessRate: 76,
    trends: {
        dropoutRate: {
            2021: 14.2,
            2022: 13.5,
            2023: 12.9,
            2024: 12.4
        },
        literacyRate: {
            2021: 76.1,
            2022: 77.0,
            2023: 77.8,
            2024: 78.6
        }
    }
};

// Age group analysis data
const ageGroupData = {
    "6-10 years": {
        dropoutRate: 8.2,
        enrollmentRate: 95.3,
        population: 580000
    },
    "11-14 years": {
        dropoutRate: 14.6,
        enrollmentRate: 87.4,
        population: 620000
    },
    "15-17 years": {
        dropoutRate: 18.9,
        enrollmentRate: 78.2,
        population: 480000
    },
    "18+ years": {
        dropoutRate: 22.3,
        enrollmentRate: 45.7,
        population: 770000
    }
};

// Gender-wise statistics
const genderData = {
    male: {
        dropoutRate: 11.2,
        literacyRate: 82.4,
        enrollmentRate: 89.3
    },
    female: {
        dropoutRate: 13.8,
        literacyRate: 74.8,
        enrollmentRate: 85.7
    }
};

// Monthly trend data for charts
const monthlyTrends = {
    dropoutRate: [
        { month: 'Jan 2024', value: 13.2 },
        { month: 'Feb 2024', value: 12.9 },
        { month: 'Mar 2024', value: 12.7 },
        { month: 'Apr 2024', value: 12.5 },
        { month: 'May 2024', value: 12.4 },
        { month: 'Jun 2024', value: 12.2 }
    ],
    literacyRate: [
        { month: 'Jan 2024', value: 77.8 },
        { month: 'Feb 2024', value: 78.0 },
        { month: 'Mar 2024', value: 78.2 },
        { month: 'Apr 2024', value: 78.4 },
        { month: 'May 2024', value: 78.5 },
        { month: 'Jun 2024', value: 78.6 }
    ],
    enrollment: [
        { month: 'Jan 2024', value: 86.2 },
        { month: 'Feb 2024', value: 86.8 },
        { month: 'Mar 2024', value: 87.1 },
        { month: 'Apr 2024', value: 87.5 },
        { month: 'May 2024', value: 87.8 },
        { month: 'Jun 2024', value: 88.0 }
    ]
};

// User credentials for demo
const userCredentials = {
    government: {
        email: 'gov@example.com',
        password: 'gov123',
        name: 'Government User',
        role: 'government',
        permissions: {
            viewMap: true,
            viewAnalysis: true,
            viewCampaigns: true,
            createCampaigns: false,
            editCampaigns: false,
            deleteCampaigns: false
        }
    },
    ngo: {
        email: 'ngo@example.com',
        password: 'ngo123',
        name: 'NGO User',
        role: 'ngo',
        permissions: {
            viewMap: true,
            viewAnalysis: true,
            viewCampaigns: true,
            createCampaigns: true,
            editCampaigns: true,
            deleteCampaigns: true
        }
    }
};

// Export functions for use in other files
function getRegionalData() {
    return regionalData;
}

function getCampaignsData() {
    return campaignsData;
}

function getNationalStats() {
    return nationalStats;
}

function getAgeGroupData() {
    return ageGroupData;
}

function getGenderData() {
    return genderData;
}

function getMonthlyTrends() {
    return monthlyTrends;
}

function getUserCredentials() {
    return userCredentials;
}

function getRegionByCode(regionCode) {
    return regionalData[regionCode] || null;
}

function getCampaignById(campaignId) {
    return campaignsData.find(campaign => campaign.id === campaignId) || null;
}

function getCampaignsByRegion(regionCode) {
    return campaignsData.filter(campaign => campaign.region === regionCode);
}

function getCampaignsByStatus(status) {
    return campaignsData.filter(campaign => campaign.status === status);
}

function getCampaignsByType(type) {
    return campaignsData.filter(campaign => campaign.type === type);
}

// Helper functions for data manipulation
function calculateRegionalAverage(metric) {
    const regions = Object.values(regionalData);
    const total = regions.reduce((sum, region) => sum + region[metric].overall, 0);
    return (total / regions.length).toFixed(1);
}

function getTopPerformingRegions(metric, count = 5) {
    return Object.entries(regionalData)
        .sort((a, b) => {
            if (metric === 'dropoutRate') {
                return a[1][metric].overall - b[1][metric].overall; // Lower is better
            } else {
                return b[1][metric].overall - a[1][metric].overall; // Higher is better
            }
        })
        .slice(0, count)
        .map(([code, data]) => ({ code, ...data }));
}

function getWorstPerformingRegions(metric, count = 5) {
    return Object.entries(regionalData)
        .sort((a, b) => {
            if (metric === 'dropoutRate') {
                return b[1][metric].overall - a[1][metric].overall; // Higher is worse
            } else {
                return a[1][metric].overall - b[1][metric].overall; // Lower is worse
            }
        })
        .slice(0, count)
        .map(([code, data]) => ({ code, ...data }));
}

// Make functions available globally
if (typeof window !== 'undefined') {
    window.DataStore = {
        getRegionalData,
        getCampaignsData,
        getNationalStats,
        getAgeGroupData,
        getGenderData,
        getMonthlyTrends,
        getUserCredentials,
        getRegionByCode,
        getCampaignById,
        getCampaignsByRegion,
        getCampaignsByStatus,
        getCampaignsByType,
        calculateRegionalAverage,
        getTopPerformingRegions,
        getWorstPerformingRegions
    };
}