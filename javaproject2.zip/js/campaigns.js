// Campaign management system with role-based permissions

let campaignsData = [];
let currentFilter = 'all';
let editingCampaignId = null;

// Initialize campaigns page when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.campaigns-grid')) {
        initializeCampaignsPage();
    }
});

function initializeCampaignsPage() {
    loadCampaignsData();
    setupRoleBasedAccess();
    initializeCampaignControls();
    initializeModals();
    displayCampaigns();
    
    // Log page access
    AuthManager.logActivity('campaigns_page_loaded', {
        userRole: AuthManager.getUserRole(),
        canCreateCampaigns: AuthManager.hasPermission('createCampaigns')
    });
}

function loadCampaignsData() {
    campaignsData = DataStore.getCampaignsData();
    updateCampaignStats();
}

function updateCampaignStats() {
    const totalCampaigns = campaignsData.length;
    const activeCampaigns = campaignsData.filter(c => c.status === 'active').length;
    const totalReach = campaignsData.reduce((sum, c) => sum + c.actualReach, 0);
    const completedCampaigns = campaignsData.filter(c => c.status === 'completed');
    const avgSuccessRate = completedCampaigns.length > 0 
        ? Math.round(completedCampaigns.reduce((sum, c) => sum + c.successRate, 0) / completedCampaigns.length)
        : 0;
    
    // Update statistics display
    updateStatElement('totalCampaigns', totalCampaigns);
    updateStatElement('activeCampaignsCount', activeCampaigns);
    updateStatElement('totalReach', formatReachNumber(totalReach));
    updateStatElement('successRate', avgSuccessRate + '%');
}

function updateStatElement(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = value;
    }
}

function formatReachNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K';
    }
    return num.toString();
}

function setupRoleBasedAccess() {
    const userRole = AuthManager.getUserRole();
    const createButton = document.getElementById('createCampaignBtn');
    const governmentInfo = document.getElementById('governmentInfo');
    
    if (userRole === 'government') {
        // Government users: view-only access
        if (createButton) createButton.style.display = 'none';
        if (governmentInfo) governmentInfo.style.display = 'block';
    } else if (userRole === 'ngo') {
        // NGO users: full access
        if (createButton) createButton.style.display = 'flex';
        if (governmentInfo) governmentInfo.style.display = 'none';
    }
}

function initializeCampaignControls() {
    // Filter dropdown
    const campaignFilter = document.getElementById('campaignFilter');
    if (campaignFilter) {
        campaignFilter.addEventListener('change', function() {
            currentFilter = this.value;
            displayCampaigns();
            
            AuthManager.logActivity('campaign_filter_changed', {
                newFilter: currentFilter
            });
        });
    }
    
    // Create campaign button
    const createButton = document.getElementById('createCampaignBtn');
    if (createButton) {
        createButton.addEventListener('click', function() {
            if (AuthManager.hasPermission('createCampaigns')) {
                openCampaignModal();
            } else {
                showAccessDeniedMessage();
            }
        });
    }
}

function initializeModals() {
    // Campaign modal controls
    const closeModalBtn = document.getElementById('closeModalBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const campaignForm = document.getElementById('campaignForm');
    const closeDetailModalBtn = document.getElementById('closeDetailModalBtn');
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeCampaignModal);
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeCampaignModal);
    }
    
    if (campaignForm) {
        campaignForm.addEventListener('submit', handleCampaignSubmit);
    }
    
    if (closeDetailModalBtn) {
        closeDetailModalBtn.addEventListener('click', closeCampaignDetailModal);
    }
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        const modal = e.target.closest('.modal');
        if (e.target.classList.contains('modal')) {
            if (modal.id === 'campaignModal') {
                closeCampaignModal();
            } else if (modal.id === 'campaignDetailModal') {
                closeCampaignDetailModal();
            }
        }
    });
}

function displayCampaigns() {
    const campaignsGrid = document.getElementById('campaignsGrid');
    if (!campaignsGrid) return;
    
    let filteredCampaigns = campaignsData;
    
    // Apply filter
    if (currentFilter !== 'all') {
        filteredCampaigns = campaignsData.filter(campaign => campaign.status === currentFilter);
    }
    
    // Sort by creation date (newest first)
    filteredCampaigns.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));
    
    if (filteredCampaigns.length === 0) {
        campaignsGrid.innerHTML = `
            <div class="no-campaigns">
                <div class="no-campaigns-content">
                    <i class="fas fa-bullhorn"></i>
                    <h3>No campaigns found</h3>
                    <p>No campaigns match the selected filter criteria.</p>
                    ${AuthManager.hasPermission('createCampaigns') ? 
                        '<button class="create-btn" onclick="openCampaignModal()"><i class="fas fa-plus"></i> Create First Campaign</button>' : 
                        ''
                    }
                </div>
            </div>
        `;
        return;
    }
    
    const campaignCardsHTML = filteredCampaigns.map(campaign => createCampaignCard(campaign)).join('');
    campaignsGrid.innerHTML = campaignCardsHTML;
}

function createCampaignCard(campaign) {
    const regionData = DataStore.getRegionByCode(campaign.region);
    const regionName = regionData ? regionData.name : 'Unknown Region';
    const progressPercentage = Math.round((campaign.actualReach / campaign.expectedReach) * 100);
    const canEdit = AuthManager.hasPermission('editCampaigns');
    
    return `
        <div class="campaign-card" onclick="showCampaignDetails(${campaign.id})">
            <div class="campaign-status ${campaign.status}">${campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}</div>
            
            <div class="campaign-header">
                <h3 class="campaign-title">${campaign.name}</h3>
                <span class="campaign-type ${campaign.type}">${campaign.type}</span>
            </div>
            
            <div class="campaign-content">
                <div class="campaign-meta">
                    <div class="meta-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${regionName}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-users"></i>
                        <span>${campaign.targetAudience}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>${formatDate(campaign.startDate)}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-money-bill-wave"></i>
                        <span>₹${formatBudget(campaign.budget)}</span>
                    </div>
                </div>
                
                <p class="campaign-description">${campaign.description}</p>
                
                <div class="campaign-progress">
                    <div class="progress-header">
                        <span>Progress</span>
                        <span>${progressPercentage}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${Math.min(progressPercentage, 100)}%"></div>
                    </div>
                    <div class="progress-details">
                        <span>${formatReachNumber(campaign.actualReach)} / ${formatReachNumber(campaign.expectedReach)} people reached</span>
                    </div>
                </div>
                
                <div class="campaign-stats">
                    <div class="campaign-stat">
                        <span class="value">${formatReachNumber(campaign.actualReach)}</span>
                        <span class="label">Reached</span>
                    </div>
                    <div class="campaign-stat">
                        <span class="value">${campaign.successRate}%</span>
                        <span class="label">Success Rate</span>
                    </div>
                    <div class="campaign-stat">
                        <span class="value">₹${formatBudget(campaign.budget)}</span>
                        <span class="label">Budget</span>
                    </div>
                </div>
                
                ${canEdit ? `
                    <div class="campaign-actions" onclick="event.stopPropagation()">
                        <button class="action-btn edit-btn" onclick="editCampaign(${campaign.id})" title="Edit Campaign">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete-btn" onclick="deleteCampaign(${campaign.id})" title="Delete Campaign">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function formatBudget(budget) {
    if (budget >= 10000000) {
        return (budget / 10000000).toFixed(1) + 'Cr';
    } else if (budget >= 100000) {
        return (budget / 100000).toFixed(1) + 'L';
    } else if (budget >= 1000) {
        return (budget / 1000).toFixed(0) + 'K';
    }
    return budget.toString();
}

function openCampaignModal(campaign = null) {
    const modal = document.getElementById('campaignModal');
    const modalTitle = document.getElementById('modalTitle');
    const submitBtnText = document.getElementById('submitBtnText');
    const form = document.getElementById('campaignForm');
    
    if (!modal) return;
    
    editingCampaignId = campaign ? campaign.id : null;
    
    // Update modal title and button text
    if (campaign) {
        modalTitle.textContent = 'Edit Campaign';
        submitBtnText.textContent = 'Update Campaign';
        populateCampaignForm(campaign);
    } else {
        modalTitle.textContent = 'Create New Campaign';
        submitBtnText.textContent = 'Create Campaign';
        form.reset();
    }
    
    modal.classList.add('active');
    
    // Set minimum dates
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const today = new Date().toISOString().split('T')[0];
    
    if (startDateInput) startDateInput.min = today;
    if (endDateInput) endDateInput.min = today;
    
    // Add start date change listener to update end date minimum
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            endDateInput.min = this.value;
        });
    }
}

function populateCampaignForm(campaign) {
    document.getElementById('campaignName').value = campaign.name;
    document.getElementById('campaignType').value = campaign.type;
    document.getElementById('targetRegion').value = campaign.region;
    document.getElementById('targetAudience').value = campaign.targetAudience;
    document.getElementById('startDate').value = campaign.startDate;
    document.getElementById('endDate').value = campaign.endDate;
    document.getElementById('budget').value = campaign.budget;
    document.getElementById('campaignDescription').value = campaign.description;
    document.getElementById('expectedReach').value = campaign.expectedReach;
}

function closeCampaignModal() {
    const modal = document.getElementById('campaignModal');
    if (modal) {
        modal.classList.remove('active');
        editingCampaignId = null;
    }
}

function handleCampaignSubmit(e) {
    e.preventDefault();
    
    if (!AuthManager.hasPermission('createCampaigns') && !editingCampaignId) {
        showAccessDeniedMessage();
        return;
    }
    
    if (!AuthManager.hasPermission('editCampaigns') && editingCampaignId) {
        showAccessDeniedMessage();
        return;
    }
    
    const formData = new FormData(e.target);
    const campaignData = {
        name: formData.get('name'),
        type: formData.get('type'),
        region: formData.get('region'),
        targetAudience: formData.get('audience'),
        startDate: formData.get('startDate'),
        endDate: formData.get('endDate'),
        budget: parseInt(formData.get('budget')),
        description: formData.get('description'),
        expectedReach: parseInt(formData.get('expectedReach')) || 0
    };
    
    // Validate form data
    const validation = validateCampaignData(campaignData);
    if (!validation.isValid) {
        showFormErrors(validation.errors);
        return;
    }
    
    if (editingCampaignId) {
        updateCampaign(editingCampaignId, campaignData);
    } else {
        createNewCampaign(campaignData);
    }
}

function validateCampaignData(data) {
    const errors = [];
    
    if (!data.name || data.name.trim().length < 3) {
        errors.push('Campaign name must be at least 3 characters long');
    }
    
    if (!data.type) {
        errors.push('Please select a campaign type');
    }
    
    if (!data.region) {
        errors.push('Please select a target region');
    }
    
    if (!data.targetAudience) {
        errors.push('Please select target audience');
    }
    
    if (!data.startDate || !data.endDate) {
        errors.push('Please provide both start and end dates');
    }
    
    if (data.startDate && data.endDate && new Date(data.startDate) >= new Date(data.endDate)) {
        errors.push('End date must be after start date');
    }
    
    if (!data.budget || data.budget < 1000) {
        errors.push('Budget must be at least ₹1,000');
    }
    
    if (!data.description || data.description.trim().length < 10) {
        errors.push('Description must be at least 10 characters long');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors
    };
}

function createNewCampaign(campaignData) {
    const newCampaign = {
        id: Math.max(...campaignsData.map(c => c.id)) + 1,
        ...campaignData,
        status: 'planned',
        actualReach: 0,
        successRate: 0,
        createdBy: 'ngo',
        createdDate: new Date().toISOString().split('T')[0],
        activities: [],
        metrics: {}
    };
    
    campaignsData.unshift(newCampaign);
    
    // Log campaign creation
    AuthManager.logActivity('campaign_created', {
        campaignId: newCampaign.id,
        campaignName: newCampaign.name,
        type: newCampaign.type,
        region: newCampaign.region
    });
    
    updateCampaignStats();
    displayCampaigns();
    closeCampaignModal();
    
    showSuccessMessage(`Campaign "${newCampaign.name}" created successfully!`);
}

function updateCampaign(campaignId, campaignData) {
    const campaignIndex = campaignsData.findIndex(c => c.id === campaignId);
    
    if (campaignIndex !== -1) {
        campaignsData[campaignIndex] = {
            ...campaignsData[campaignIndex],
            ...campaignData
        };
        
        // Log campaign update
        AuthManager.logActivity('campaign_updated', {
            campaignId: campaignId,
            campaignName: campaignData.name
        });
        
        updateCampaignStats();
        displayCampaigns();
        closeCampaignModal();
        
        showSuccessMessage(`Campaign "${campaignData.name}" updated successfully!`);
    }
}

function editCampaign(campaignId) {
    if (!AuthManager.hasPermission('editCampaigns')) {
        showAccessDeniedMessage();
        return;
    }
    
    const campaign = campaignsData.find(c => c.id === campaignId);
    if (campaign) {
        openCampaignModal(campaign);
    }
}

function deleteCampaign(campaignId) {
    if (!AuthManager.hasPermission('deleteCampaigns')) {
        showAccessDeniedMessage();
        return;
    }
    
    const campaign = campaignsData.find(c => c.id === campaignId);
    if (!campaign) return;
    
    if (confirm(`Are you sure you want to delete the campaign "${campaign.name}"?`)) {
        const campaignIndex = campaignsData.findIndex(c => c.id === campaignId);
        
        if (campaignIndex !== -1) {
            campaignsData.splice(campaignIndex, 1);
            
            // Log campaign deletion
            AuthManager.logActivity('campaign_deleted', {
                campaignId: campaignId,
                campaignName: campaign.name
            });
            
            updateCampaignStats();
            displayCampaigns();
            
            showSuccessMessage(`Campaign "${campaign.name}" deleted successfully!`);
        }
    }
}

function showCampaignDetails(campaignId) {
    const campaign = campaignsData.find(c => c.id === campaignId);
    if (!campaign) return;
    
    const modal = document.getElementById('campaignDetailModal');
    const modalTitle = document.getElementById('detailModalTitle');
    const modalContent = document.getElementById('campaignDetailContent');
    
    if (!modal || !modalTitle || !modalContent) return;
    
    modalTitle.textContent = campaign.name;
    modalContent.innerHTML = createDetailedCampaignContent(campaign);
    modal.classList.add('active');
    
    // Log campaign detail view
    AuthManager.logActivity('campaign_detail_viewed', {
        campaignId: campaignId,
        campaignName: campaign.name
    });
}

function createDetailedCampaignContent(campaign) {
    const regionData = DataStore.getRegionByCode(campaign.region);
    const regionName = regionData ? regionData.name : 'Unknown Region';
    const progressPercentage = Math.round((campaign.actualReach / campaign.expectedReach) * 100);
    const canEdit = AuthManager.hasPermission('editCampaigns');
    
    return `
        <div class="campaign-detail-header">
            <div class="detail-basic-info">
                <div class="detail-item">
                    <label>Type:</label>
                    <span class="campaign-type ${campaign.type}">${campaign.type}</span>
                </div>
                <div class="detail-item">
                    <label>Status:</label>
                    <span class="campaign-status ${campaign.status}">${campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}</span>
                </div>
                <div class="detail-item">
                    <label>Target Region:</label>
                    <span>${regionName}</span>
                </div>
                <div class="detail-item">
                    <label>Target Audience:</label>
                    <span>${campaign.targetAudience.charAt(0).toUpperCase() + campaign.targetAudience.slice(1)}</span>
                </div>
                <div class="detail-item">
                    <label>Duration:</label>
                    <span>${formatDate(campaign.startDate)} - ${formatDate(campaign.endDate)}</span>
                </div>
                <div class="detail-item">
                    <label>Budget:</label>
                    <span>₹${formatBudget(campaign.budget)}</span>
                </div>
            </div>
            
            ${canEdit ? `
                <div class="detail-actions">
                    <button class="action-btn edit-btn" onclick="editCampaign(${campaign.id}); closeCampaignDetailModal();">
                        <i class="fas fa-edit"></i> Edit Campaign
                    </button>
                    <button class="action-btn delete-btn" onclick="deleteCampaign(${campaign.id}); closeCampaignDetailModal();">
                        <i class="fas fa-trash"></i> Delete Campaign
                    </button>
                </div>
            ` : ''}
        </div>
        
        <div class="detail-section">
            <h4>Description</h4>
            <p>${campaign.description}</p>
        </div>
        
        <div class="detail-section">
            <h4>Progress & Metrics</h4>
            <div class="progress-section">
                <div class="progress-header">
                    <span>Overall Progress</span>
                    <span>${progressPercentage}%</span>
                </div>
                <div class="progress-bar large">
                    <div class="progress-fill" style="width: ${Math.min(progressPercentage, 100)}%"></div>
                </div>
                <div class="progress-details">
                    <span>${formatReachNumber(campaign.actualReach)} of ${formatReachNumber(campaign.expectedReach)} people reached</span>
                </div>
            </div>
            
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="metric-info">
                        <span class="metric-value">${formatReachNumber(campaign.actualReach)}</span>
                        <span class="metric-label">People Reached</span>
                    </div>
                </div>
                <div class="metric-card">
                    <div class="metric-icon">
                        <i class="fas fa-target"></i>
                    </div>
                    <div class="metric-info">
                        <span class="metric-value">${campaign.successRate}%</span>
                        <span class="metric-label">Success Rate</span>
                    </div>
                </div>
                <div class="metric-card">
                    <div class="metric-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="metric-info">
                        <span class="metric-value">₹${formatBudget(campaign.budget)}</span>
                        <span class="metric-label">Total Budget</span>
                    </div>
                </div>
            </div>
        </div>
        
        ${campaign.activities && campaign.activities.length > 0 ? `
            <div class="detail-section">
                <h4>Activities</h4>
                <ul class="activity-list">
                    ${campaign.activities.map(activity => `
                        <li class="activity-item">
                            <i class="fas fa-check-circle"></i>
                            <span>${activity}</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        ` : ''}
        
        <div class="detail-section">
            <h4>Campaign Information</h4>
            <div class="info-grid">
                <div class="info-item">
                    <label>Created By:</label>
                    <span>${campaign.createdBy.toUpperCase()}</span>
                </div>
                <div class="info-item">
                    <label>Created On:</label>
                    <span>${formatDate(campaign.createdDate)}</span>
                </div>
                <div class="info-item">
                    <label>Expected Reach:</label>
                    <span>${formatReachNumber(campaign.expectedReach)} people</span>
                </div>
            </div>
        </div>
    `;
}

function closeCampaignDetailModal() {
    const modal = document.getElementById('campaignDetailModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

function showAccessDeniedMessage() {
    alert('Access denied. Only NGO users can create and manage campaigns.');
}

function showSuccessMessage(message) {
    // Create and show success toast
    const toast = document.createElement('div');
    toast.className = 'success-toast';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

function showFormErrors(errors) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'form-errors';
    errorContainer.innerHTML = `
        <div class="error-content">
            <h4><i class="fas fa-exclamation-triangle"></i> Please fix the following errors:</h4>
            <ul>
                ${errors.map(error => `<li>${error}</li>`).join('')}
            </ul>
        </div>
    `;
    
    const form = document.getElementById('campaignForm');
    const existingErrors = form.querySelector('.form-errors');
    
    if (existingErrors) {
        existingErrors.remove();
    }
    
    form.insertBefore(errorContainer, form.firstChild);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
        errorContainer.remove();
    }, 10000);
}

// Add campaign-specific styles
const campaignStyles = `
    .no-campaigns {
        grid-column: 1 / -1;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 400px;
    }
    
    .no-campaigns-content {
        text-align: center;
        color: var(--gray-600);
    }
    
    .no-campaigns-content i {
        font-size: 48px;
        color: var(--gray-400);
        margin-bottom: 16px;
    }
    
    .no-campaigns-content h3 {
        margin-bottom: 8px;
        color: var(--gray-900);
    }
    
    .campaign-progress {
        margin: 16px 0;
    }
    
    .progress-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--gray-700);
    }
    
    .progress-bar {
        height: 6px;
        background: var(--gray-200);
        border-radius: 3px;
        overflow: hidden;
    }
    
    .progress-bar.large {
        height: 8px;
        border-radius: 4px;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--primary-color), var(--success-color));
        transition: width 0.3s ease;
    }
    
    .progress-details {
        margin-top: 4px;
        font-size: 11px;
        color: var(--gray-500);
    }
    
    .campaign-actions {
        display: flex;
        gap: 8px;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid var(--gray-200);
    }
    
    .action-btn {
        padding: 8px 12px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 12px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: var(--transition);
    }
    
    .edit-btn {
        background: var(--primary-color);
        color: white;
    }
    
    .edit-btn:hover {
        background: var(--primary-dark);
    }
    
    .delete-btn {
        background: var(--danger-color);
        color: white;
    }
    
    .delete-btn:hover {
        background: #dc2626;
    }
    
    .campaign-detail-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 24px;
        gap: 24px;
    }
    
    .detail-basic-info {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
        flex: 1;
    }
    
    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    
    .detail-item label {
        font-size: 12px;
        font-weight: 600;
        color: var(--gray-600);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .detail-actions {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    
    .detail-section {
        margin-bottom: 32px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--gray-200);
    }
    
    .detail-section:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .detail-section h4 {
        margin-bottom: 16px;
        color: var(--gray-900);
        font-size: 18px;
    }
    
    .metrics-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-top: 20px;
    }
    
    .metric-card {
        background: var(--gray-50);
        padding: 20px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .metric-icon {
        width: 40px;
        height: 40px;
        background: var(--primary-color);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 18px;
    }
    
    .metric-info {
        display: flex;
        flex-direction: column;
    }
    
    .metric-value {
        font-size: 20px;
        font-weight: 700;
        color: var(--gray-900);
    }
    
    .metric-label {
        font-size: 12px;
        color: var(--gray-600);
    }
    
    .activity-list {
        list-style: none;
        display: grid;
        gap: 12px;
    }
    
    .activity-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        background: var(--gray-50);
        border-radius: 6px;
    }
    
    .activity-item i {
        color: var(--success-color);
        font-size: 14px;
    }
    
    .info-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
    }
    
    .info-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    
    .success-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border: 1px solid var(--success-color);
        border-left: 4px solid var(--success-color);
        border-radius: 8px;
        box-shadow: var(--shadow-lg);
        padding: 16px;
        z-index: 10000;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .success-toast.show {
        transform: translateX(0);
        opacity: 1;
    }
    
    .success-toast .toast-content {
        display: flex;
        align-items: center;
        gap: 12px;
        color: var(--success-color);
    }
    
    .form-errors {
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid var(--danger-color);
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 20px;
    }
    
    .error-content h4 {
        color: var(--danger-color);
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .error-content ul {
        color: var(--danger-color);
        margin-left: 20px;
    }
    
    .error-content li {
        margin-bottom: 4px;
    }
    
    .progress-section {
        background: var(--gray-50);
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .detail-basic-info {
            grid-template-columns: 1fr;
        }
        
        .campaign-detail-header {
            flex-direction: column;
        }
        
        .detail-actions {
            flex-direction: row;
        }
        
        .metrics-grid {
            grid-template-columns: 1fr;
        }
        
        .info-grid {
            grid-template-columns: 1fr;
        }
    }
`;

// Add campaign styles to document
const campaignStyleSheet = document.createElement('style');
campaignStyleSheet.textContent = campaignStyles;
document.head.appendChild(campaignStyleSheet);