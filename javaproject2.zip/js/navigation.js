// Navigation and sidebar functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeSidebar();
    handleLogout();
    updateUserInterface();
});

function initializeNavigation() {
    // Update user information in navigation
    AuthManager.updateUserInfoInUI();
    
    // Handle permission-based UI visibility
    AuthManager.handlePermissionBasedUI();
    
    // Set active navigation item based on current page
    setActiveNavigation();
    
    // Add navigation click handlers
    addNavigationHandlers();
}

function initializeSidebar() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            
            // Log activity
            AuthManager.logActivity('sidebar_toggle', {
                collapsed: sidebar.classList.contains('collapsed')
            });
        });
    }
    
    // Handle responsive sidebar
    handleResponsiveSidebar();
}

function handleResponsiveSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 1024) {
            if (sidebar && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        }
    });
    
    // Toggle sidebar on mobile
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            
            if (window.innerWidth <= 1024) {
                sidebar.classList.toggle('active');
            }
        });
    }
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
        }
    });
}

function setActiveNavigation() {
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        const navItem = link.closest('.nav-item');
        
        // Remove active class from all nav items
        navItem.classList.remove('active');
        
        // Add active class to current page nav item
        if (href === currentPage) {
            navItem.classList.add('active');
        }
    });
}

function addNavigationHandlers() {
    const navLinks = document.querySelectorAll('.nav-link:not(#logoutBtn)');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Log navigation activity
            AuthManager.logActivity('page_navigation', {
                from: window.location.pathname,
                to: href,
                timestamp: new Date().toISOString()
            });
        });
    });
}

function handleLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation dialog
            if (confirm('Are you sure you want to logout?')) {
                // Log logout activity
                AuthManager.logActivity('logout', {
                    timestamp: new Date().toISOString(),
                    sessionDuration: calculateSessionDuration()
                });
                
                // Perform logout
                AuthManager.logout();
            }
        });
    }
}

function calculateSessionDuration() {
    const currentUser = AuthManager.getCurrentUser();
    if (currentUser && currentUser.loginTime) {
        const loginTime = new Date(currentUser.loginTime);
        const currentTime = new Date();
        const duration = currentTime - loginTime;
        return Math.round(duration / (1000 * 60)); // Duration in minutes
    }
    return 0;
}

function updateUserInterface() {
    const currentUser = AuthManager.getCurrentUser();
    
    if (!currentUser) {
        return;
    }
    
    // Update user role display
    const userRoleElement = document.getElementById('userRole');
    if (userRoleElement) {
        userRoleElement.textContent = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
        
        // Add role-specific styling
        userRoleElement.className = `user-role role-${currentUser.role}`;
    }
    
    // Update user avatar based on role
    const userAvatar = document.querySelector('.user-avatar i');
    if (userAvatar) {
        if (currentUser.role === 'government') {
            userAvatar.className = 'fas fa-user-tie';
        } else if (currentUser.role === 'ngo') {
            userAvatar.className = 'fas fa-users';
        }
    }
    
    // Add welcome message for new sessions
    showWelcomeMessage(currentUser);
    
    // Initialize tooltips and help text
    initializeTooltips();
}

function showWelcomeMessage(user) {
    const loginTime = new Date(user.loginTime);
    const now = new Date();
    const timeSinceLogin = now - loginTime;
    
    // Show welcome message only for sessions less than 5 minutes old
    if (timeSinceLogin < 5 * 60 * 1000) {
        const welcomeMessage = createWelcomeMessage(user);
        showToast(welcomeMessage, 'success', 5000);
    }
}

function createWelcomeMessage(user) {
    const currentPage = window.location.pathname.split('/').pop();
    let pageContext = '';
    
    switch (currentPage) {
        case 'map.html':
            pageContext = 'Explore regional dropout and literacy data on the interactive map.';
            break;
        case 'analysis.html':
            pageContext = 'View comprehensive statistics and trends in educational data.';
            break;
        case 'campaigns.html':
            if (user.role === 'ngo') {
                pageContext = 'Manage your awareness campaigns and track their effectiveness.';
            } else {
                pageContext = 'View ongoing awareness campaigns and their progress.';
            }
            break;
        default:
            pageContext = 'Welcome to the dashboard!';
    }
    
    return `Welcome back, ${user.name}! ${pageContext}`;
}

function showToast(message, type = 'info', duration = 3000) {
    // Remove existing toast if present
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas ${getToastIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add to page
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    // Auto-hide toast
    const hideToast = () => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 300);
    };
    
    setTimeout(hideToast, duration);
    
    // Handle close button
    const closeButton = toast.querySelector('.toast-close');
    closeButton.addEventListener('click', hideToast);
}

function getToastIcon(type) {
    switch (type) {
        case 'success':
            return 'fa-check-circle';
        case 'error':
            return 'fa-exclamation-circle';
        case 'warning':
            return 'fa-exclamation-triangle';
        default:
            return 'fa-info-circle';
    }
}

function initializeTooltips() {
    // Add tooltips to navigation items for government users
    const currentUser = AuthManager.getCurrentUser();
    
    if (currentUser && currentUser.role === 'government') {
        const campaignsLink = document.querySelector('a[href="campaigns.html"]');
        if (campaignsLink) {
            campaignsLink.title = 'View-only access - Only NGOs can create campaigns';
            campaignsLink.setAttribute('data-tooltip', 'View-only access');
        }
    }
}

// Breadcrumb functionality
function initializeBreadcrumbs() {
    const breadcrumbContainer = document.createElement('div');
    breadcrumbContainer.className = 'breadcrumb-container';
    
    const currentPage = window.location.pathname.split('/').pop();
    const pageHeaders = document.querySelector('.page-header');
    
    if (pageHeaders) {
        const breadcrumbs = generateBreadcrumbs(currentPage);
        breadcrumbContainer.innerHTML = breadcrumbs;
        pageHeaders.insertBefore(breadcrumbContainer, pageHeaders.firstChild);
    }
}

function generateBreadcrumbs(currentPage) {
    const breadcrumbMap = {
        'map.html': 'Regional Map',
        'analysis.html': 'Data Analysis',
        'campaigns.html': 'Campaigns'
    };
    
    const pageName = breadcrumbMap[currentPage] || 'Dashboard';
    
    return `
        <nav class="breadcrumb">
            <a href="map.html" class="breadcrumb-item">
                <i class="fas fa-home"></i>
                Dashboard
            </a>
            <span class="breadcrumb-separator">/</span>
            <span class="breadcrumb-current">${pageName}</span>
        </nav>
    `;
}

// Handle keyboard shortcuts
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Alt + M for Map
        if (e.altKey && e.key === 'm') {
            e.preventDefault();
            window.location.href = 'map.html';
        }
        
        // Alt + A for Analysis
        if (e.altKey && e.key === 'a') {
            e.preventDefault();
            window.location.href = 'analysis.html';
        }
        
        // Alt + C for Campaigns
        if (e.altKey && e.key === 'c') {
            e.preventDefault();
            window.location.href = 'campaigns.html';
        }
        
        // Ctrl + L for Logout (with confirmation)
        if (e.ctrlKey && e.key === 'l') {
            e.preventDefault();
            const logoutBtn = document.getElementById('logoutBtn');
            if (logoutBtn) {
                logoutBtn.click();
            }
        }
    });
}

// Add CSS for toast notifications and breadcrumbs
const navigationStyles = `
    .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        padding: 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 300px;
        z-index: 10000;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .toast.show {
        transform: translateX(0);
        opacity: 1;
    }
    
    .toast-content {
        display: flex;
        align-items: center;
        gap: 12px;
        flex: 1;
    }
    
    .toast-success {
        border-left: 4px solid var(--success-color);
    }
    
    .toast-error {
        border-left: 4px solid var(--danger-color);
    }
    
    .toast-warning {
        border-left: 4px solid var(--warning-color);
    }
    
    .toast-info {
        border-left: 4px solid var(--info-color);
    }
    
    .toast-close {
        background: none;
        border: none;
        cursor: pointer;
        padding: 4px;
        border-radius: 4px;
        color: var(--gray-500);
    }
    
    .toast-close:hover {
        background: var(--gray-100);
        color: var(--gray-700);
    }
    
    .breadcrumb-container {
        margin-bottom: 16px;
    }
    
    .breadcrumb {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        color: var(--gray-600);
    }
    
    .breadcrumb-item {
        color: var(--primary-color);
        text-decoration: none;
        transition: color 0.2s ease;
    }
    
    .breadcrumb-item:hover {
        color: var(--primary-dark);
    }
    
    .breadcrumb-separator {
        color: var(--gray-400);
    }
    
    .breadcrumb-current {
        color: var(--gray-900);
        font-weight: 500;
    }
    
    .role-government {
        color: var(--primary-color);
    }
    
    .role-ngo {
        color: var(--success-color);
    }
`;

// Add styles to document
const navStyleSheet = document.createElement('style');
navStyleSheet.textContent = navigationStyles;
document.head.appendChild(navStyleSheet);

// Initialize additional features when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeBreadcrumbs();
    initializeKeyboardShortcuts();
});