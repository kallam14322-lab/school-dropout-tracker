// Authentication and Session Management System

class AuthManager {
    constructor() {
        this.currentUser = null;
        this.sessionKey = 'dropout_tracker_session';
        this.init();
    }

    init() {
        // Load saved session if exists
        this.loadSession();
        
        // Check authentication on protected pages
        this.checkAuthenticationOnLoad();
    }

    // Load session from localStorage
    loadSession() {
        const savedSession = localStorage.getItem(this.sessionKey);
        if (savedSession) {
            try {
                this.currentUser = JSON.parse(savedSession);
            } catch (error) {
                console.error('Error loading session:', error);
                this.clearSession();
            }
        }
    }

    // Save session to localStorage
    saveSession() {
        if (this.currentUser) {
            localStorage.setItem(this.sessionKey, JSON.stringify(this.currentUser));
        }
    }

    // Clear session from localStorage
    clearSession() {
        localStorage.removeItem(this.sessionKey);
        this.currentUser = null;
    }

    // Authenticate user with credentials
    authenticate(email, password, userType) {
        const credentials = DataStore.getUserCredentials();
        
        // Check if credentials match
        const user = credentials[userType];
        if (user && user.email === email && user.password === password) {
            this.currentUser = {
                ...user,
                loginTime: new Date().toISOString(),
                sessionId: this.generateSessionId()
            };
            
            this.saveSession();
            return {
                success: true,
                user: this.currentUser,
                message: 'Login successful'
            };
        }
        
        return {
            success: false,
            message: 'Invalid email or password'
        };
    }

    // Generate unique session ID
    generateSessionId() {
        return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    }

    // Check if user is authenticated
    isAuthenticated() {
        return this.currentUser !== null;
    }

    // Get current user
    getCurrentUser() {
        return this.currentUser;
    }

    // Check user permissions
    hasPermission(permission) {
        if (!this.currentUser || !this.currentUser.permissions) {
            return false;
        }
        return this.currentUser.permissions[permission] === true;
    }

    // Get user role
    getUserRole() {
        return this.currentUser ? this.currentUser.role : null;
    }

    // Logout user
    logout() {
        this.clearSession();
        this.redirectToLogin();
    }

    // Redirect to login page
    redirectToLogin() {
        window.location.href = 'index.html';
    }

    // Redirect to dashboard
    redirectToDashboard() {
        window.location.href = 'map.html';
    }

    // Check authentication on page load
    checkAuthenticationOnLoad() {
        const currentPage = window.location.pathname.split('/').pop();
        const protectedPages = ['map.html', 'analysis.html', 'campaigns.html'];
        
        if (protectedPages.includes(currentPage)) {
            if (!this.isAuthenticated()) {
                this.redirectToLogin();
                return;
            }
            
            // Update user info in UI
            this.updateUserInfoInUI();
        }
        
        // If on login page and already authenticated, redirect to dashboard
        if (currentPage === 'index.html' || currentPage === '') {
            if (this.isAuthenticated()) {
                this.redirectToDashboard();
            }
        }
    }

    // Update user information in the UI
    updateUserInfoInUI() {
        if (!this.currentUser) return;
        
        const userNameElement = document.getElementById('userName');
        const userRoleElement = document.getElementById('userRole');
        
        if (userNameElement) {
            userNameElement.textContent = this.currentUser.name;
        }
        
        if (userRoleElement) {
            userRoleElement.textContent = this.currentUser.role.charAt(0).toUpperCase() + this.currentUser.role.slice(1);
        }
    }

    // Show/hide elements based on user permissions
    handlePermissionBasedUI() {
        if (!this.currentUser) return;
        
        const role = this.currentUser.role;
        
        // Handle campaign creation button visibility
        const createCampaignBtn = document.getElementById('createCampaignBtn');
        if (createCampaignBtn) {
            if (this.hasPermission('createCampaigns')) {
                createCampaignBtn.style.display = 'flex';
            } else {
                createCampaignBtn.style.display = 'none';
            }
        }
        
        // Handle government access info
        const governmentInfo = document.getElementById('governmentInfo');
        if (governmentInfo) {
            if (role === 'government') {
                governmentInfo.style.display = 'block';
            } else {
                governmentInfo.style.display = 'none';
            }
        }
        
        // Handle campaign action buttons in campaign cards
        const campaignCards = document.querySelectorAll('.campaign-card');
        campaignCards.forEach(card => {
            const editBtn = card.querySelector('.edit-campaign-btn');
            const deleteBtn = card.querySelector('.delete-campaign-btn');
            
            if (editBtn && deleteBtn) {
                if (this.hasPermission('editCampaigns')) {
                    editBtn.style.display = 'inline-flex';
                    deleteBtn.style.display = 'inline-flex';
                } else {
                    editBtn.style.display = 'none';
                    deleteBtn.style.display = 'none';
                }
            }
        });
    }

    // Validate session (check if not expired)
    validateSession() {
        if (!this.currentUser) return false;
        
        const loginTime = new Date(this.currentUser.loginTime);
        const currentTime = new Date();
        const sessionDuration = 8 * 60 * 60 * 1000; // 8 hours in milliseconds
        
        if (currentTime - loginTime > sessionDuration) {
            this.clearSession();
            return false;
        }
        
        return true;
    }

    // Extend session (update login time)
    extendSession() {
        if (this.currentUser) {
            this.currentUser.loginTime = new Date().toISOString();
            this.saveSession();
        }
    }

    // Get user dashboard preferences
    getUserPreferences() {
        const preferencesKey = `${this.sessionKey}_preferences`;
        const savedPreferences = localStorage.getItem(preferencesKey);
        
        if (savedPreferences) {
            try {
                return JSON.parse(savedPreferences);
            } catch (error) {
                console.error('Error loading preferences:', error);
            }
        }
        
        // Default preferences
        return {
            theme: 'light',
            defaultRegion: 'all',
            chartType: 'bar',
            notifications: true
        };
    }

    // Save user dashboard preferences
    saveUserPreferences(preferences) {
        const preferencesKey = `${this.sessionKey}_preferences`;
        localStorage.setItem(preferencesKey, JSON.stringify(preferences));
    }

    // Handle form validation
    validateLoginForm(email, password, userType) {
        const errors = [];
        
        if (!email) {
            errors.push('Email is required');
        } else if (!this.isValidEmail(email)) {
            errors.push('Please enter a valid email address');
        }
        
        if (!password) {
            errors.push('Password is required');
        } else if (password.length < 3) {
            errors.push('Password must be at least 3 characters long');
        }
        
        if (!userType) {
            errors.push('Please select user type (Government or NGO)');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    // Email validation helper
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Display error messages
    displayError(message, containerId = 'errorContainer') {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${message}</span>
                </div>
            `;
            container.style.display = 'block';
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                container.style.display = 'none';
            }, 5000);
        }
    }

    // Display success messages
    displaySuccess(message, containerId = 'successContainer') {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span>${message}</span>
                </div>
            `;
            container.style.display = 'block';
            
            // Auto-hide after 3 seconds
            setTimeout(() => {
                container.style.display = 'none';
            }, 3000);
        }
    }

    // Activity logging
    logActivity(action, details = {}) {
        if (!this.currentUser) return;
        
        const activity = {
            userId: this.currentUser.sessionId,
            userRole: this.currentUser.role,
            action: action,
            details: details,
            timestamp: new Date().toISOString(),
            page: window.location.pathname
        };
        
        // Store in session storage (could be sent to server in real implementation)
        const activitiesKey = `${this.sessionKey}_activities`;
        const activities = JSON.parse(sessionStorage.getItem(activitiesKey) || '[]');
        activities.push(activity);
        
        // Keep only last 100 activities
        if (activities.length > 100) {
            activities.splice(0, activities.length - 100);
        }
        
        sessionStorage.setItem(activitiesKey, JSON.stringify(activities));
    }

    // Get user activities
    getUserActivities() {
        const activitiesKey = `${this.sessionKey}_activities`;
        return JSON.parse(sessionStorage.getItem(activitiesKey) || '[]');
    }

    // Security features
    detectSuspiciousActivity() {
        const activities = this.getUserActivities();
        const recentActivities = activities.filter(activity => {
            const activityTime = new Date(activity.timestamp);
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
            return activityTime > fiveMinutesAgo;
        });
        
        // Check for too many login attempts
        const loginAttempts = recentActivities.filter(activity => 
            activity.action === 'login_attempt'
        );
        
        if (loginAttempts.length > 5) {
            return {
                suspicious: true,
                reason: 'Too many login attempts',
                action: 'temporary_lock'
            };
        }
        
        return { suspicious: false };
    }
}

// Initialize authentication manager
const authManager = new AuthManager();

// Make authentication manager available globally
if (typeof window !== 'undefined') {
    window.AuthManager = authManager;
}

// Also make the class available globally for reference
if (typeof window !== 'undefined') {
    window.AuthManagerClass = AuthManager;
}

// Auto-extend session on activity
document.addEventListener('click', () => {
    if (authManager.isAuthenticated()) {
        authManager.extendSession();
    }
});

document.addEventListener('keypress', () => {
    if (authManager.isAuthenticated()) {
        authManager.extendSession();
    }
});

// Session validation on page visibility change
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && authManager.isAuthenticated()) {
        if (!authManager.validateSession()) {
            alert('Your session has expired. Please log in again.');
            authManager.redirectToLogin();
        }
    }
});